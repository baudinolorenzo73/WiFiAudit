#!/usr/bin/env python3
"""WiFiAudit 6: local data handling; no radio capture or password engine here."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import zipfile


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def trusted(path):
    p = Path(path).absolute()
    for item in (p, *p.parents):
        st = item.lstat()
        if stat.S_ISLNK(st.st_mode) or st.st_uid not in (0, os.geteuid()) or st.st_mode & 0o022:
            raise ValueError('Percorso non fidato: ' + str(item))
    return p


def atomic_json(path, data):
    path = Path(path)
    fd, temp = tempfile.mkstemp(dir=path.parent, prefix='.state-')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            json.dump(data, out, ensure_ascii=True, indent=2)
            out.write('\n')
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def inspect(path):
    p = Path(path)
    if p.is_symlink() or not p.is_file():
        raise ValueError('Serve un file regolare, non un link')
    with p.open('rb') as f:
        magic = f.read(12)
    result = {'file': str(p.absolute()), 'bytes': p.stat().st_size, 'sha256': digest(p),
              'formato': 'sconosciuto', 'stato': 'NON_RICONOSCIUTO', 'handshake_valido': 'non_verificato'}
    if magic[:4] in (b'\xd4\xc3\xb2\xa1', b'\xa1\xb2\xc3\xd4', b'\x4d\x3c\xb2\xa1', b'\xa1\xb2\x3c\x4d'):
        result.update(formato='pcap', stato='HEADER_RICONOSCIUTO' if result['bytes'] >= 24 else 'TRONCATO')
    elif magic[:4] == b'\x0a\x0d\x0d\x0a':
        result.update(formato='pcapng', stato='HEADER_RICONOSCIUTO' if result['bytes'] >= 28 else 'TRONCATO')
    elif p.suffix.lower() == '.22000':
        good = bad = 0
        with p.open('r', encoding='ascii', errors='replace') as f:
            for line in f:
                if not line.strip():
                    continue
                fields = line.rstrip('\r\n').split('*')
                valid = len(fields) >= 9 and fields[0] == 'WPA' and fields[1] in ('01', '02')
                for idx, length in ((2, 32), (3, 12), (4, 12)):
                    field = fields[idx] if len(fields) > idx else ''
                    valid = valid and len(field) == length and all(c in '0123456789abcdefABCDEF' for c in field)
                good += bool(valid)
                bad += not valid
        result.update(formato='22000', righe_conformi=good, righe_non_conformi=bad,
                      stato='SINTASSI_CONFORME' if good and not bad else 'DA_VERIFICARE')
    elif p.suffix.lower() == '.john':
        result.update(formato='john', stato='FORMATO_DICHIARATO_NON_VALIDATO')
    if result['formato'] in ('pcap', 'pcapng') and shutil.which('tshark'):
        try:
            r = subprocess.run(['tshark', '-n', '-r', str(p), '-Y', 'eapol', '-T', 'fields', '-e', 'frame.number'],
                               capture_output=True, text=True, timeout=20)
            result.update(tshark_exit=r.returncode, eapol_frames=len(r.stdout.splitlines()))
        except subprocess.TimeoutExpired:
            result['tshark'] = 'TIMEOUT'
    return result


def files_in(root):
    root = Path(root)
    for p in sorted(root.rglob('*')):
        if p.is_symlink() or not p.is_file():
            continue
        if any((root / x).is_symlink() for x in p.relative_to(root).parents if str(x) != '.'):
            continue
        yield p


def backup(root, destination):
    root = trusted(root)
    if not root.name.startswith('session_'):
        raise ValueError('Seleziona una singola cartella session_*')
    dest = Path(destination).absolute()
    trusted(dest.parent)
    if root == dest or root in dest.parents:
        raise ValueError('Il backup deve essere fuori dalla sessione')
    fd = os.open(dest, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    manifest = []
    try:
        with os.fdopen(fd, 'wb') as out, zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED) as z:
            for p in files_in(root):
                rel = p.relative_to(root)
                # Recheck just before opening; directory is private/owned.
                trusted(p)
                info = zipfile.ZipInfo.from_file(p, str(Path(root.name) / rel))
                info.compress_type = zipfile.ZIP_DEFLATED
                h, count = hashlib.sha256(), 0
                with os.fdopen(os.open(p, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as source, z.open(info, 'w') as target:
                    while chunk := source.read(1024 * 1024):
                        h.update(chunk)
                        count += len(chunk)
                        target.write(chunk)
                manifest.append({'path': str(rel), 'sha256': h.hexdigest(), 'bytes': count})
            z.writestr(root.name + '/backup_manifest.json', json.dumps(manifest, indent=2))
    except BaseException:
        dest.unlink(missing_ok=True)
        raise
    return {'backup': str(dest), 'files': len(manifest), 'encrypted': False}


def checkpoint_signature(input_file):
    wl = os.environ.get('WORDLIST', '')
    return {'input': digest(input_file), 'wordlist': digest(wl) if Path(wl).is_file() else None,
            **{k: os.environ.get(k, '') for k in ('JOHN_RULES', 'JOHN_MASK', 'HC_MASK', 'AUTO_USE_MASK')}}


def checkpoint_begin(input_file, destination, resume):
    dest = trusted(destination)
    sig = checkpoint_signature(input_file)
    done = []
    if resume:
        src = trusted(resume)
        data = json.loads(trusted(src / 'checkpoint.json').read_text())
        if data.get('signature') != sig:
            raise ValueError('Input o impostazioni modificati: ripresa rifiutata; avvia una nuova sessione')
        done = data.get('completed', [])
        if not isinstance(done, list) or not all(x in ('hashcat:wordlist', 'hashcat:regole', 'hashcat:maschera',
                                                      'john:wordlist', 'john:regole', 'john:maschera') for x in done):
            raise ValueError('Checkpoint non valido')
        for name in ('auto_hashcat.pot', 'auto_john.pot'):
            if (src / name).exists():
                shutil.copyfile(trusted(src / name), dest / name)
                os.chmod(dest / name, 0o600)
    data = {'version': 1, 'input': str(Path(input_file).resolve()), 'signature': sig,
            'completed': done, 'updated': int(time.time())}
    atomic_json(dest / 'checkpoint.json', data)
    (dest / 'completed.txt').write_text('\n'.join(done) + ('\n' if done else ''), encoding='ascii')
    os.chmod(dest / 'completed.txt', 0o600)
    return data


def run(args):
    if args.cmd == 'inspect':
        return inspect(args.path)
    if args.cmd == 'catalog':
        root = trusted(args.path)
        return [{'session': str(p), 'files': sum(1 for _ in files_in(p)),
                 'checkpoint': (p / 'checkpoint.json').is_file()} for p in sorted(root.glob('session_*'))
                if p.is_dir() and not p.is_symlink()]
    if args.cmd == 'backup':
        return backup(args.path, args.output)
    if args.cmd == 'begin':
        return checkpoint_begin(args.input, args.path, args.resume)
    if args.cmd == 'complete':
        if args.stage not in ('hashcat:wordlist', 'hashcat:regole', 'hashcat:maschera',
                              'john:wordlist', 'john:regole', 'john:maschera'):
            raise ValueError('Fase non valida')
        path = trusted(Path(args.path) / 'checkpoint.json')
        data = json.loads(path.read_text())
        if args.stage not in data['completed']:
            data['completed'].append(args.stage)
        data['updated'] = int(time.time())
        atomic_json(path, data)
        return {'saved': True}
    if args.cmd == 'resume-input':
        path = trusted(Path(args.path) / 'checkpoint.json')
        data = json.loads(path.read_text())
        source = data.get('input')
        if not isinstance(source, str) or '\0' in source or not Path(source).is_file():
            raise ValueError('Input originale non disponibile')
        if digest(source) != data.get('signature', {}).get('input'):
            raise ValueError('Il file originale e cambiato')
        sys.stdout.buffer.write(source.encode() + b'\0')
        return None
    if args.cmd == 'import-wifite':
        path = trusted(args.path)
        if path.stat().st_size > 10 * 1024 * 1024:
            raise ValueError('Risultati troppo grandi')
        data = json.loads(path.read_text())
        if not isinstance(data, list):
            raise ValueError('Schema Wifite non riconosciuto')
        seen = set()
        for item in data:
            if not isinstance(item, dict) or str(item.get('bssid', '')).lower() != args.bssid.lower():
                continue
            key, essid = item.get('key'), item.get('essid', '')
            if not isinstance(key, str) or not key or not isinstance(essid, str) or '\0' in key + essid:
                continue
            if item.get('type') not in ('WPA', 'WPS', 'PMKID') or key in seen:
                continue
            seen.add(key)
            sys.stdout.buffer.write(essid.encode() + b'\0' + key.encode() + b'\0')
        return None
    if args.cmd == 'filter-22000':
        target = args.bssid.replace(':', '').lower()
        if len(target) != 12 or any(c not in '0123456789abcdef' for c in target):
            raise ValueError('BSSID non valido')
        count = 0
        with open(args.path, encoding='ascii', errors='strict') as source:
            fd = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(fd, 'w', encoding='ascii') as out:
                for line in source:
                    fields = line.rstrip('\r\n').split('*')
                    if len(fields) >= 9 and fields[0] == 'WPA' and fields[1] in ('01', '02') and fields[3].lower() == target:
                        out.write(line.rstrip('\r\n') + '\n')
                        count += 1
        return {'selected': count, 'bssid': args.bssid}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('cmd', choices=['inspect', 'catalog', 'backup', 'begin', 'complete', 'resume-input', 'import-wifite', 'filter-22000'])
    p.add_argument('path')
    p.add_argument('--output')
    p.add_argument('--input')
    p.add_argument('--resume', default='')
    p.add_argument('--stage')
    p.add_argument('--bssid')
    args = p.parse_args()
    try:
        data = run(args)
        if data is not None:
            print(json.dumps(data, ensure_ascii=True, indent=2))
        return 0
    except (OSError, ValueError, TypeError, KeyError) as e:
        print('Errore: ' + str(e), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
