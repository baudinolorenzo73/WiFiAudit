#!/usr/bin/env python3
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock
import zipfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('tools', ROOT / 'wifiaudit_tools.py')
tools = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tools)


class DataTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='wifiaudit-tests-', dir=Path.home())
        self.base = Path(self.temp.name)
        self.env = mock.patch.dict(os.environ, {'WORDLIST': str(self.base / 'wordlist'), 'JOHN_RULES': 'none',
                                               'JOHN_MASK': '?d', 'HC_MASK': '?d', 'AUTO_USE_MASK': 'yes'})
        self.env.start()

    def tearDown(self):
        self.env.stop()
        self.temp.cleanup()

    def file(self, name, data=b'data'):
        p = self.base / name
        p.write_bytes(data)
        p.chmod(0o600)
        return p

    def test_pcap_header_not_handshake(self):
        p = self.file('test.cap', b'\xd4\xc3\xb2\xa1' + b'\0' * 20)
        with mock.patch.object(tools.shutil, 'which', return_value=None):
            r = tools.inspect(p)
        self.assertEqual(r['formato'], 'pcap')
        self.assertEqual(r['handshake_valido'], 'non_verificato')

    def test_truncated_pcap(self):
        with mock.patch.object(tools.shutil, 'which', return_value=None):
            r = tools.inspect(self.file('test.cap', b'\xd4\xc3\xb2\xa1'))
        self.assertEqual(r['stato'], 'TRONCATO')

    def test_pcapng_header(self):
        with mock.patch.object(tools.shutil, 'which', return_value=None):
            r = tools.inspect(self.file('test.pcapng', b'\x0a\x0d\x0d\x0a' + b'\0'*24))
        self.assertEqual(r['formato'], 'pcapng')

    def test_22000_valid_syntax(self):
        data = ('WPA*01*' + '0'*32 + '*' + 'a'*12 + '*' + 'b'*12 + '*74657374***\n').encode()
        r = tools.inspect(self.file('test.22000', data))
        self.assertEqual(r['righe_conformi'], 1)
        self.assertEqual(r['stato'], 'SINTASSI_CONFORME')

    def test_bad_hash_rejected_as_conformant(self):
        r = tools.inspect(self.file('bad.22000', b'WPA*01*oops\n'))
        self.assertEqual(r['righe_non_conformi'], 1)

    def test_filter_hashes_to_one_bssid(self):
        prefix = 'WPA*01*' + '0'*32 + '*'
        self.file('mixed.22000', (prefix + 'aabbccddeeff*' + 'b'*12 + '*74657374***\n' +
                                prefix + '112233445566*' + 'b'*12 + '*74657374***\n').encode())
        dest = self.base / 'selected.22000'
        r = subprocess.run(['python3', str(ROOT / 'wifiaudit_tools.py'), 'filter-22000', str(self.base / 'mixed.22000'),
                            '--bssid', 'AA:BB:CC:DD:EE:FF', '--output', str(dest)], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(len(dest.read_text().splitlines()), 1)
        self.assertNotIn('112233445566', dest.read_text())

    def test_inspect_symlink_rejected(self):
        p = self.file('original')
        q = self.base / 'link.cap'
        q.symlink_to(p)
        with self.assertRaises(ValueError):
            tools.inspect(q)

    def test_backup_private_manifest(self):
        session = self.base / 'session_x'
        session.mkdir(mode=0o700)
        (session / 'results.tsv').write_text('secret')
        dest = self.base / 'backup.zip'
        r = tools.backup(session, dest)
        self.assertFalse(r['encrypted'])
        self.assertEqual(dest.stat().st_mode & 0o777, 0o600)
        with zipfile.ZipFile(dest) as z:
            manifest = json.loads(z.read('session_x/backup_manifest.json'))
            self.assertEqual(manifest[0]['sha256'], tools.digest(session / 'results.tsv'))

    def test_backup_ignores_symlinks(self):
        session = self.base / 'session_x'
        session.mkdir(mode=0o700)
        (session / 'secret_link').symlink_to(self.file('outside_secret'))
        (session / 'dir_link').symlink_to(self.base, target_is_directory=True)
        r = tools.backup(session, self.base / 'backup.zip')
        self.assertEqual(r['files'], 0)

    def test_backup_does_not_overwrite(self):
        session = self.base / 'session_x'
        session.mkdir(mode=0o700)
        dest = self.file('exists.zip', b'keep')
        with self.assertRaises(FileExistsError):
            tools.backup(session, dest)
        self.assertEqual(dest.read_bytes(), b'keep')

    def test_backup_outside_session(self):
        session = self.base / 'session_x'
        session.mkdir(mode=0o700)
        with self.assertRaises(ValueError):
            tools.backup(session, session / 'backup.zip')

    def test_backup_refuses_broad_root(self):
        with self.assertRaises(ValueError):
            tools.backup(self.base, self.base / 'backup.zip')

    def test_untrusted_directory(self):
        p = self.base / 'shared'
        p.mkdir(mode=0o777)
        p.chmod(0o777)
        with self.assertRaises(ValueError):
            tools.trusted(p)

    def test_checkpoint_roundtrip(self):
        inp = self.file('input.22000')
        src, dest = self.base / 'session_old', self.base / 'session_new'
        src.mkdir(mode=0o700); dest.mkdir(mode=0o700)
        tools.checkpoint_begin(inp, src, '')
        data = json.loads((src / 'checkpoint.json').read_text())
        data['completed'] = ['hashcat:wordlist']
        tools.atomic_json(src / 'checkpoint.json', data)
        (src / 'auto_hashcat.pot').write_text('private')
        r = tools.checkpoint_begin(inp, dest, str(src))
        self.assertEqual(r['completed'], ['hashcat:wordlist'])
        self.assertEqual((dest / 'auto_hashcat.pot').read_text(), 'private')

    def test_changed_input_refuses_resume(self):
        inp = self.file('input.22000')
        src, dest = self.base / 'session_old', self.base / 'session_new'
        src.mkdir(mode=0o700); dest.mkdir(mode=0o700)
        tools.checkpoint_begin(inp, src, '')
        inp.write_bytes(b'changed')
        with self.assertRaises(ValueError):
            tools.checkpoint_begin(inp, dest, str(src))

    def test_changed_wordlist_refuses_resume(self):
        inp = self.file('input.22000')
        wl = self.file('wordlist', b'first')
        src, dest = self.base / 'session_old', self.base / 'session_new'
        src.mkdir(mode=0o700); dest.mkdir(mode=0o700)
        tools.checkpoint_begin(inp, src, '')
        wl.write_bytes(b'second')
        with self.assertRaises(ValueError):
            tools.checkpoint_begin(inp, dest, str(src))

    def shell(self, body, stdin=''):
        cmd = 'source "$1"; OUTDIR="$CASE_ROOT/results"; CONFIG_FILE="$CASE_ROOT/no_config"; ' + body
        return subprocess.run(['bash', '-c', cmd, 'test', str(ROOT / 'wifiaudit.sh')], input=stdin,
                              text=True, capture_output=True, timeout=20,
                              env={**os.environ, 'CASE_ROOT': str(self.base)})

    def test_self_test_without_root(self):
        r = self.shell('main --self-test')
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn('0 errori', r.stdout)

    def test_menu_eof_no_radio(self):
        r = self.shell('setup_monitor(){ return 98; }; main --menu')
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertFalse((self.base / 'results').exists())

    def test_html_tsv_preserve_special_values(self):
        r = self.shell('[[ "$(html_escape "<script>&")" == "&lt;script&gt;&amp;" ]] || exit 1; '
                       '[[ "$(tsv_escape $\'a\\tb\\nc\')" == \'a\\tb\\nc\' ]]')
        self.assertEqual(r.returncode, 0, r.stderr)

    def test_guided_target_and_scoped_import(self):
        r = self.shell(self.guided_stub('AA:BB:CC:DD:EE:FF'), self.guided_stdin())
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        rows = (self.base / 'results/passwords.tsv').read_text()
        self.assertIn('fixture_password', rows)
        args = next((self.base / 'results').glob('session_*/args.txt')).read_text()
        self.assertIn('-b\nAA:BB:CC:DD:EE:FF', args)
        for flag in ('--nodeauths', '--no-wps', '--no-pmkid'):
            self.assertIn(flag, args)
        self.assertNotIn('--kill', args)

    def test_guided_other_bssid_not_imported(self):
        r = self.shell(self.guided_stub('11:22:33:44:55:66'), self.guided_stdin())
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        self.assertEqual((self.base / 'results/passwords.tsv').read_text(), '')

    def test_guided_no_consent_no_radio(self):
        r = self.shell(self.guided_stub('AA:BB:CC:DD:EE:FF'), '\n\n\nwlan9\n1\n5\nn\n')
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertFalse((self.base / 'results').exists())

    def test_guided_missing_bssid_filter_refused(self):
        body = self.guided_stub('AA:BB:CC:DD:EE:FF').replace('-b --dict --wpa', '--dict --wpa')
        r = self.shell(body, self.guided_stdin())
        self.assertEqual(r.returncode, 2, r.stdout + r.stderr)
        self.assertFalse((self.base / 'results').exists())

    def guided_stdin(self):
        return '\n\n\nwlan9\n1\n5\ns\n'

    def guided_stub(self, bssid):
        return '''TARGET_BSSID=AA:BB:CC:DD:EE:FF; TARGET_CHAN=6;
        v6_require_root(){ return 0; }
        timeout(){ while [[ "$1" == -* ]]; do shift 2; done; shift; "$@"; }
        wifite(){
          if [[ "$1" == -h ]]; then
            printf '%s\\n' '-b --dict --wpa --skip-crack --nodeauths --no-wps --no-pmkid'; return 0;
          fi
          printf '%s\\n' "$@" > args.txt
          printf '%s\\n' '[{"type":"WPA","bssid":"''' + bssid + '''","essid":"test","key":"fixture_password"}]' > cracked.json
        }
        v6_guided'''

    def test_offline_success_checkpoint_and_parent_state(self):
        inp = self.file('fixture.22000')
        self.file('wordlist', b'candidate\n')
        r = self.shell('WORDLIST="$CASE_ROOT/wordlist"; '
                       'timeout(){ shift 3; "$@"; }; '
                       'hashcat(){ [[ " $* " != *" --show "* ]] || printf "fixture_password\\n"; }; '
                       'auto_recover "$CASE_ROOT/fixture.22000" || exit 1; '
                       '[[ -z "$SESSION_ID" && "$LAST_AUTO_STATUS" == TROVATA ]]')
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertEqual(len(list((self.base / 'results').glob('session_*/checkpoint.json'))), 1)

    def test_resume_skips_completed_phases(self):
        self.file('fixture.22000')
        self.file('wordlist', b'candidate\n')
        r = self.shell('WORDLIST="$CASE_ROOT/wordlist"; AUTO_USE_MASK=no; JOHN_RULES=none; '
                       'timeout(){ shift 3; "$@"; }; '
                       'hashcat(){ [[ " $* " == *" --show "* ]] && return 0; echo called >> "$CASE_ROOT/calls"; return 1; }; '
                       'auto_recover "$CASE_ROOT/fixture.22000"; src="$LAST_AUTO_DIR"; '
                       'v6_resume "$src"; '
                       '[[ "$(wc -l < "$CASE_ROOT/calls")" == 1 && "$LAST_AUTO_STATUS" == FASI_GIA_COMPLETATE ]]')
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
