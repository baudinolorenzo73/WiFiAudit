// DOM behavior smoke test without dependencies; this does not validate CSS rendering.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.resolve(__dirname, '..');

class Element {
  constructor(tag = 'div') { this.tag = tag; this.children = []; this.handlers = {}; this.classList = {add(){}, toggle(){}}; this.style = {}; this.textContent = ''; this.hidden = false; this.disabled = false; this._value = ''; this.selectedIndex = 0; }
  append(...nodes) { this.children.push(...nodes); }
  replaceChildren(...nodes) { this.children = [...nodes]; }
  setAttribute() {} scrollIntoView() {} select() {} remove() {}
  addEventListener(type, callback) { (this.handlers[type] ||= []).push(callback); }
  async click() { for (const callback of this.handlers.click || []) await callback({currentTarget: this}); }
  get value() { return this.tag === 'select' ? this.children[this.selectedIndex]?.value || '' : this._value; }
  set value(value) { this._value = value; if(this.tag === 'select') { const idx = this.children.findIndex(x => x.value === value); if(idx >= 0) this.selectedIndex = idx; } }
}

(async () => {
  const nodes = new Map();
  const get = id => { if (!nodes.has(id)) nodes.set(id, new Element(id.startsWith('snapshot') ? 'select' : 'div')); return nodes.get(id); };
  const document = {
    querySelector(query) { if (query.includes('token')) return {content: '__TOKEN__'}; if (query.includes('version')) return {content: '1.7.0'}; return get(query); },
    querySelectorAll() { return []; }, getElementById: get,
    createElement: tag => new Element(tag), body: new Element(), addEventListener() {}
  };
  const window = {isSecureContext: false, addEventListener(){}, dispatchEvent(){}, confirm(){return true;}, open(){}};
  const context = vm.createContext({document, window, navigator: {}, location: {hostname: 'example.github.io'}, console, setTimeout(){return 1;}, clearTimeout(){}, URL, Blob, Event});
  vm.runInContext(fs.readFileSync(path.join(root, 'app.js'), 'utf8'), context);
  vm.runInContext(fs.readFileSync(path.join(root, 'dashboard-ui.js'), 'utf8'), context);
  assert.equal(get('packageGroups').children.length, 8);
  assert.equal(get('utilityGrid').children.length, 16);
  assert.equal(get('webPreview').hidden, false);
  await get('demoScans').click();
  assert.equal(get('snapshotAfter').children.length, 2);
  await get('compareScans').click();
  const result = JSON.parse(get('diffOutput').textContent);
  assert.equal(result.added.length, 1);
  assert.equal(result.not_observed.length, 1);
  assert.equal(result.changed.length, 1);
  assert.equal(result.demo, true);
  console.log('PASS: static dashboard, 8 groups, 16 utilities, demo import and comparison');
})().catch(error => { console.error(error); process.exit(1); });
