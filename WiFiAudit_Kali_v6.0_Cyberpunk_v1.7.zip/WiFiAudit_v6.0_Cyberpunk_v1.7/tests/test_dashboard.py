import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock
from urllib.request import Request, urlopen
from urllib.error import HTTPError

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import dashboard
import launcher

CSV = b'BSSID, First time seen, Last time seen, channel, Speed, Privacy, Cipher, Authentication, Power, # beacons, # IV, LAN IP, ID-length, ESSID, Key\n02:00:00:00:00:01, a, b, 1, 54, WPA2, CCMP, PSK, -50, 1, 0, 0, 3, Lab,\n\nStation MAC, First time seen, Last time seen, Power, # packets, BSSID, Probed ESSIDs\n02:00:00:00:00:02,a,b,-50,10,02:00:00:00:00:01,\n'


class DashboardTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path.home())
        self.home = Path(self.temp.name)
        self.patch = mock.patch.object(dashboard.Path, 'home', return_value=self.home)
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.temp.cleanup()

    def test_job_success_and_failure(self):
        good = dashboard.new_job('fixture', [sys.executable, '-c', 'pass'])
        self.assertEqual(dashboard.run_job(good), 0)
        bad = dashboard.new_job('fixture', ['/no/such/command'])
        self.assertEqual(dashboard.run_job(bad), 127)
        self.assertEqual({x['status'] for x in dashboard.jobs()}, {'COMPLETATA', 'FALLITA'})

    def test_simulation_does_not_execute(self):
        path = self.home / 'never-created'
        ident = dashboard.new_job('sim', ['touch', str(path)], simulated=True)
        self.assertEqual(dashboard.run_job(ident), 2)
        self.assertFalse(path.exists())
        self.assertEqual(dashboard.jobs()[0]['status'], 'SIMULATA')

    def test_stale_job_is_unknown_not_success(self):
        ident = dashboard.new_job('lost', ['true'])
        with dashboard.connect() as db:
            db.execute('UPDATE jobs SET updated=? WHERE id=?', (time.time() - 60, ident))
        self.assertEqual(dashboard.jobs()[0]['status'], 'STATO_SCONOSCIUTO')

    def test_import_and_diff_without_station_rows(self):
        path = self.home / 'scan.csv'; path.write_bytes(CSV)
        before = dashboard.import_scan(path)['id']
        path.write_bytes(CSV.replace(b', 1, 54,', b', 6, 54,'))
        after = dashboard.import_scan(path)['id']
        result = dashboard.diff(before, after)
        self.assertEqual(result['changed'][0]['changes']['channel'], {'before': '1', 'after': '6'})
        self.assertEqual(dashboard.snapshots()[0]['networks'], 1)
        self.assertEqual((dashboard.state_dir() / 'history.sqlite3').stat().st_mode & 0o777, 0o600)

    def test_file_link_size_and_invalid_csv_rejected(self):
        path = self.home / 'scan.csv'; path.write_bytes(CSV)
        link = self.home / 'link.csv'; link.symlink_to(path)
        with self.assertRaises(ValueError): dashboard.import_scan(link)
        with self.assertRaises(ValueError): dashboard.read_limited(path, 3)
        with self.assertRaises(ValueError): dashboard.parse_scan(b'not,a,scan')

    def test_catalog_reads_status_field_and_not_explanation(self):
        root = self.home / 'results'; folder = root / 'session_example'; folder.mkdir(parents=True)
        (folder / 'auto_risultato.txt').write_text('Esito: TEMPO_ESAURITO\nNON_TROVATA significa nessun risultato\npassword: private-secret', encoding='utf-8')
        data = dashboard.session_catalog(root)
        self.assertEqual(data[0]['status'], 'TEMPO_ESAURITO')
        self.assertNotIn('private-secret', json.dumps(data))

    def test_job_script_preserves_multiline_argument_as_data(self):
        import subprocess
        value = 'a\n; echo SHOULD_NOT_RUN\n#'
        script = launcher.make_job([sys.executable, '-c', 'pass', value], False, 'fixture')
        self.assertEqual(subprocess.run(['bash', '-n', str(script)], capture_output=True).returncode, 0)
        self.assertEqual(dashboard.jobs()[0]['command'][-1], value)

    def test_kismet_api_is_readonly_and_key_not_stored(self):
        key = 'fixture-private-key'
        devices = [{'kismet.device.base.macaddr': '02:00:00:00:00:01', 'kismet.device.base.name': '<script>', 'kismet.device.base.channel': '6'}]
        with mock.patch.object(dashboard, 'kismet_json', side_effect=[{}, devices]) as request:
            data = dashboard.kismet_import(key)
        self.assertEqual(data['networks'], 1)
        self.assertEqual(request.call_args_list[0].args[0], '/system/status.json')
        self.assertEqual(request.call_args_list[1].args[0], '/devices/views/phydot11_accesspoints/last-time/0/devices.json')
        self.assertNotIn(key.encode(), (dashboard.state_dir() / 'history.sqlite3').read_bytes())
        with self.assertRaises(ValueError): dashboard.kismet_json('/evil', key, 2501)
        with self.assertRaises(ValueError): dashboard.kismet_json('/system/status.json', 'key\r\nX: evil', 2501)

    def test_http_protection_and_dry_run(self):
        server = launcher.AppServer(('127.0.0.1', 0), 'a' * 64)
        thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
        origin = f'http://127.0.0.1:{server.server_port}'
        try:
            with self.assertRaises(HTTPError) as error: urlopen(origin + '/api/dashboard')
            self.assertEqual(error.exception.code, 403)
            headers = {'X-WiFiAudit-Token': 'a' * 64, 'Origin': origin, 'Content-Type': 'application/json'}
            req = Request(origin + '/api/action', data=json.dumps({'action': 'menu', 'dry_run': True}).encode(), headers=headers)
            with mock.patch.object(launcher, 'launch_terminal') as terminal:
                with urlopen(req) as response: data = json.load(response)
                terminal.assert_not_called()
            self.assertTrue(data['ok']); self.assertEqual(dashboard.jobs()[0]['status'], 'SIMULATA')
            hostile = Request(origin + '/api/action', data=b'{}', headers=headers | {'Origin': 'https://attacker.invalid'})
            with self.assertRaises(HTTPError) as error: urlopen(hostile)
            self.assertEqual(error.exception.code, 403)
        finally:
            server.shutdown(); server.server_close(); thread.join()


if __name__ == '__main__':
    unittest.main(verbosity=2)
