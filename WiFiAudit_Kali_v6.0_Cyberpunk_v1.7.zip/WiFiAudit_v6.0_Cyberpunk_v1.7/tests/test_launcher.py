#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
SPEC = importlib.util.spec_from_file_location("launcher", ROOT / "launcher.py")
launcher = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(launcher)


class LauncherTests(unittest.TestCase):
    def test_static_actions_are_allowlisted(self):
        argv, sudo, title = launcher.build_action({"action": "menu"})
        self.assertEqual(argv[-1], "--menu")
        self.assertTrue(sudo)
        self.assertIn("Menu", title)
        with self.assertRaises(launcher.LaunchError):
            launcher.build_action({"action": "shell", "path": "; id"})

    def test_capture_validation_and_recovery(self):
        with tempfile.TemporaryDirectory() as tmp:
            capture = Path(tmp) / "test.22000"
            capture.write_text("WPA*02*fixture", encoding="utf-8")
            argv, sudo, _ = launcher.build_action({"action": "recover", "path": str(capture), "seconds": "600"})
            self.assertTrue(sudo)
            self.assertIn(str(capture), argv)
            self.assertEqual(argv[-2:], ["--auto-seconds", "600"])

    def test_capture_rejects_extension_and_symlink(self):
        with tempfile.TemporaryDirectory() as tmp:
            bad = Path(tmp) / "bad.txt"; bad.write_text("x", encoding="utf-8")
            with self.assertRaises(launcher.LaunchError): launcher.safe_existing_file(str(bad))
            good = Path(tmp) / "good.cap"; good.write_bytes(b"x")
            link = Path(tmp) / "link.cap"; link.symlink_to(good)
            with self.assertRaises(launcher.LaunchError): launcher.safe_existing_file(str(link))

    def test_session_validation(self):
        with tempfile.TemporaryDirectory() as tmp:
            session = Path(tmp) / "session_20261107_120000"; session.mkdir()
            self.assertEqual(launcher.safe_session_dir(str(session)), session.resolve())
            other = Path(tmp) / "other"; other.mkdir()
            with self.assertRaises(launcher.LaunchError): launcher.safe_session_dir(str(other))

    def test_duration_bounds(self):
        self.assertEqual(launcher.clamp_seconds("60"), 60)
        for value in (0, 59, 86401, "x"):
            with self.assertRaises(launcher.LaunchError): launcher.clamp_seconds(value)

    def test_job_forces_fresh_sudo_and_is_private(self):
        with tempfile.TemporaryDirectory(dir=Path.home()) as home:
            with mock.patch.object(Path, "home", return_value=Path(home)):
                job = launcher.make_job(["bash", str(launcher.CORE), "--menu"], True, "Test")
                text = job.read_text(encoding="utf-8")
                self.assertIn("sudo -k --", text)
                self.assertNotIn("password=", text.lower())
                self.assertEqual(job.stat().st_mode & 0o777, 0o700)

    def test_utility_allowlist(self):
        with mock.patch.object(launcher, "command_exists", return_value=True):
            argv, sudo, _ = launcher.build_action({"action": "install_utility", "utility": "doublecmd"})
        self.assertEqual(argv, ["apt-get", "install", "-y", "doublecmd-gtk"])
        self.assertTrue(sudo)
        with self.assertRaises(launcher.LaunchError):
            launcher.build_action({"action": "install_utility", "utility": "evil;id"})

    def test_package_install_allowlist(self):
        with mock.patch.object(launcher, "command_exists", return_value=True):
            argv, sudo, _ = launcher.build_action({"action": "install_packages", "packages": ["zip", "unzip", "7zip"]})
        self.assertEqual(argv, ["apt-get", "install", "-y", "zip", "unzip", "7zip"])
        self.assertTrue(sudo)
        for payload in (
            {"action": "install_packages", "packages": []},
            {"action": "install_packages", "packages": ["zip", ";id"]},
            {"action": "install_packages", "packages": "zip"},
        ):
            with self.assertRaises(launcher.LaunchError):
                launcher.build_action(payload)

    def test_installed_package_parser(self):
        fake = mock.Mock(stdout="zip\tii \nunzip\tii \n7zip\tun \n", returncode=1)
        with mock.patch.object(launcher.shutil, "which", return_value="/usr/bin/dpkg-query"), mock.patch.object(launcher.subprocess, "run", return_value=fake):
            installed = launcher.installed_packages()
        self.assertEqual(installed, {"zip", "unzip"})

    def test_status_does_not_expose_token_or_secrets(self):
        data = launcher.status_payload()
        self.assertNotIn("token", data)
        self.assertNotIn("password", data)
        self.assertIn("utilities", data)
        self.assertIn("package_groups", data)
        self.assertIn("package", data["utilities"]["doublecmd"])

    def test_project_pages_uses_relative_assets(self):
        html = (ROOT / "index.html").read_text(encoding="utf-8")
        self.assertIn('href="./app.css?v=1.7.0"', html)
        self.assertIn('src="./app.js?v=1.7.0"', html)
        self.assertNotIn('href="/app.css', html)
        self.assertNotIn('src="/app.js', html)

    def test_static_preview_and_pwa_files(self):
        script = (ROOT / "app.js").read_text(encoding="utf-8")
        self.assertIn("WEB_PREVIEW", script)
        self.assertIn("STATIC_PACKAGE_GROUPS", script)
        self.assertTrue((ROOT / "manifest.webmanifest").is_file())
        self.assertTrue((ROOT / "sw.js").is_file())
        self.assertTrue((ROOT / "icons" / "icon-192.png").is_file())
        self.assertTrue((ROOT / "icons" / "icon-512.png").is_file())

    def test_required_security_toolchain_is_available(self):
        required_packages = {"aircrack-ng", "kismet", "hashcat", "john", "hydra", "nmap", "wireshark"}
        self.assertTrue(required_packages.issubset(launcher.ALLOWED_PACKAGES))
        required_utilities = {"aircrack", "kismet", "hashcat", "john", "hydra", "nmap", "wireshark"}
        self.assertTrue(required_utilities.issubset(launcher.UTILITIES))
        self.assertEqual(launcher.UTILITIES["hydra"]["args"], ["-h"])

    def test_extended_wifi_catalog_is_allowlisted_but_not_automated(self):
        expected = {"tcpdump", "pixiewps", "bettercap", "fern-wifi-cracker", "mdk4", "airgeddon", "wifiphisher", "wifipumpkin3"}
        self.assertTrue(expected.issubset(launcher.ALLOWED_PACKAGES))
        self.assertEqual(launcher.UTILITIES["bettercap"]["args"], ["-h"])
        self.assertNotIn("mdk4", launcher.UTILITIES)
        self.assertNotIn("wifiphisher", launcher.UTILITIES)
        self.assertNotIn("wifipumpkin3", launcher.UTILITIES)
        self.assertNotIn("pyrit", launcher.ALLOWED_PACKAGES)


if __name__ == "__main__":
    unittest.main(verbosity=2)
