import json
import os
from pathlib import Path
import sys
import tempfile
import subprocess
import time
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import launcher
import netpwn_bridge as bridge


class NetPwnTests(unittest.TestCase):
    def test_fixed_actions_without_sudo(self):
        for action, verb in [('netpwn_install', 'install'), ('netpwn_demo', 'demo'), ('netpwn_stop', 'stop')]:
            argv, sudo, _ = launcher.build_action({'action': action, 'host': '0.0.0.0', 'args': ['--real']})
            self.assertEqual(argv, [sys.executable, str(launcher.ROOT / 'netpwn_bridge.py'), verb])
            self.assertFalse(sudo)

    def test_root_rejected(self):
        with mock.patch.object(bridge.os, 'geteuid', return_value=0):
            with self.assertRaises(ValueError): bridge.require_user()

    def test_install_pinned_venv_and_never_sudo(self):
        with tempfile.TemporaryDirectory(dir=Path.home()) as tmp, mock.patch.object(bridge, 'base_dir', return_value=Path(tmp)), mock.patch.object(bridge, 'require_user'), mock.patch.object(bridge, 'run') as run:
            bridge.install()
            commands = [x.args[0] for x in run.call_args_list]
            self.assertIn(['git', '-C', str(Path(tmp) / 'source'), 'fetch', '--depth', '1', 'origin', bridge.REVISION], commands)
            self.assertFalse(any('sudo' in x or 'run.sh' in x for x in commands))
            self.assertTrue((Path(tmp) / 'ready.json').exists())

    def test_incomplete_install_not_overwritten(self):
        with tempfile.TemporaryDirectory(dir=Path.home()) as tmp, mock.patch.object(bridge, 'base_dir', return_value=Path(tmp)), mock.patch.object(bridge, 'require_user'), mock.patch.object(bridge, 'run') as run:
            (Path(tmp) / 'source').mkdir()
            with self.assertRaises(ValueError): bridge.install()
            run.assert_not_called()

    def test_demo_not_ready_no_process(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(bridge, 'base_dir', return_value=Path(tmp)), mock.patch.object(bridge, 'require_user'), mock.patch.object(bridge.subprocess, 'Popen') as popen:
            with self.assertRaises(ValueError): bridge.demo()
            popen.assert_not_called()

    def test_demo_fixed_flags_environment_and_cleanup(self):
        with tempfile.TemporaryDirectory(dir=Path.home()) as tmp, mock.patch.object(bridge, 'base_dir', return_value=Path(tmp)), mock.patch.object(bridge, 'require_user'), mock.patch.object(bridge.signal, 'signal'), mock.patch.object(bridge.subprocess, 'Popen') as popen:
            base = Path(tmp)
            (base / 'ready.json').write_text('{}')
            python = base / 'venv/bin/python'; python.parent.mkdir(parents=True); python.touch()
            popen.return_value.poll.return_value = 0
            popen.return_value.returncode = 0
            self.assertEqual(bridge.demo(), 0)
            args, kwargs = popen.call_args
            self.assertEqual(args[0][-5:], ['--demo', '--host', '127.0.0.1', '--port', '8877'])
            self.assertEqual(kwargs['env']['NETPWN_DEMO'], '1')
            self.assertTrue(kwargs['start_new_session'])
            self.assertFalse((base / 'running.json').exists())

    def test_stop_verifies_pid_identity(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(bridge, 'base_dir', return_value=Path(tmp)), mock.patch.object(bridge, 'require_user'), mock.patch.object(bridge, 'identity') as identity, mock.patch.object(bridge.os, 'kill') as kill:
            (Path(tmp) / 'running.json').write_text(json.dumps({'pid': 4242, 'ticks': '123'}))
            cmd = str(Path(bridge.__file__).resolve()).encode() + b'\0demo\0'
            identity.return_value = ('999', bridge.os.getuid(), cmd)
            with self.assertRaises(ValueError): bridge.stop()
            kill.assert_not_called()
            identity.return_value = ('123', bridge.os.getuid(), cmd)
            bridge.stop()
            kill.assert_called_once_with(4242, bridge.signal.SIGTERM)

    def test_real_wrapper_start_stop_with_harmless_fixture(self):
        with tempfile.TemporaryDirectory(dir=Path.home()) as tmp:
            base = Path(tmp) / '.local/share/wifiaudit-netpwn' / bridge.REVISION
            source = base / 'source'; source.mkdir(parents=True)
            python = base / 'venv/bin/python'; python.parent.mkdir(parents=True); python.symlink_to(sys.executable)
            (base / 'ready.json').write_text('{}')
            (source / 'netpwn.py').write_text('import time\nwhile True: time.sleep(.1)\n')
            env = os.environ.copy(); env['HOME'] = tmp
            command = [sys.executable, str(Path(bridge.__file__).resolve())]
            process = subprocess.Popen(command + ['demo'], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            try:
                deadline = time.monotonic() + 5
                while not (base / 'running.json').exists() and process.poll() is None and time.monotonic() < deadline:
                    time.sleep(.05)
                self.assertTrue((base / 'running.json').exists())
                result = subprocess.run(command + ['stop'], env=env, capture_output=True, text=True, timeout=5)
                self.assertEqual(result.returncode, 0, result.stderr)
                process.wait(timeout=12)
                self.assertFalse((base / 'running.json').exists())
            finally:
                if process.poll() is None:
                    process.terminate(); process.wait(timeout=12)
                process.stderr.close()


if __name__ == '__main__':
    unittest.main(verbosity=2)
