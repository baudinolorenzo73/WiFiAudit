# Attività

- [x] Implementare helper: verifica, catalogo, backup, importazione e checkpoint.
- [x] Collegare menu, CLI e procedura guidata.
- [x] Verificare i percorsi senza radio e con tool simulati.
- [x] Aggiornare manuale e istruzioni, creare ZIP completo.
- [x] Preparare consegna con limiti di collaudo espliciti.
