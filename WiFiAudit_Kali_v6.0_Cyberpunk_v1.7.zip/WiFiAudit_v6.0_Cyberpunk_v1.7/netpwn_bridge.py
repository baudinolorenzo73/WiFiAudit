#!/usr/bin/env python3
"""Optional, pinned NetPwn demo integration. No upstream code bundled."""
from __future__ import annotations

import argparse
import fcntl
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time

from dashboard import private_dir

REVISION = 'c409bda64590dcba1cef2ee66188607ab14c723a'
REPOSITORY = 'https://github.com/letox4/netpwn.git'
PORT = 8877


def base_dir():
    return Path.home() / '.local' / 'share' / 'wifiaudit-netpwn' / REVISION


def paths():
    base = base_dir()
    return base, base / 'source', base / 'venv' / 'bin' / 'python'


def require_user():
    if os.geteuid() == 0:
        raise ValueError('Avvia NetPwn dal pannello come utente normale, senza sudo.')


def run(argv, **kwargs):
    subprocess.run(argv, check=True, **kwargs)


def install():
    require_user()
    base, source, python = paths()
    private_dir(base)
    with (base / 'install.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if (base / 'ready.json').exists():
            print('NetPwn già preparato. Usa Avvia demo.'); return
        if source.exists() or python.parent.parent.exists():
            raise ValueError('Preparazione incompleta. Rinomina la cartella ' + str(base) + ' e riprova; nessun file viene cancellato.')
        # Explicit network download; fixed origin and immutable revision.
        run(['git', 'init', str(source)])
        run(['git', '-C', str(source), 'remote', 'add', 'origin', REPOSITORY])
        run(['git', '-C', str(source), 'fetch', '--depth', '1', 'origin', REVISION])
        run(['git', '-C', str(source), 'checkout', '--detach', REVISION])
        run([sys.executable, '-m', 'venv', str(base / 'venv')])
        run([str(python), '-m', 'pip', 'install', '-r', str(source / 'requirements.txt')])
        (base / 'ready.json').write_text(json.dumps({'revision': REVISION, 'repository': REPOSITORY}), encoding='utf-8')
        print('Preparazione completata. Torna al pannello e premi Avvia demo.')


def identity(pid):
    """Linux start ticks prevent signalling a reused PID."""
    proc = Path('/proc') / str(pid)
    raw = (proc / 'stat').read_text()
    ticks = raw[raw.rfind(')') + 2:].split()[19]
    return ticks, proc.stat().st_uid, (proc / 'cmdline').read_bytes()


def stop():
    require_user()
    base, _, _ = paths()
    path = base / 'running.json'
    if not path.is_file() or path.is_symlink():
        print('Nessuna demo gestita da questa integrazione.'); return
    data = json.loads(path.read_text())
    pid = int(data['pid'])
    try:
        ticks, uid, cmd = identity(pid)
    except FileNotFoundError:
        print('La demo risulta già terminata.'); return
    expected = str(Path(__file__).resolve()).encode()
    if ticks != data['ticks'] or uid != os.getuid() or expected not in cmd.split(b'\0') or b'demo' not in cmd.split(b'\0'):
        raise ValueError('Identità del processo cambiata: nessun segnale inviato.')
    os.kill(pid, signal.SIGTERM)
    print('Arresto richiesto alla sola demo NetPwn gestita da WiFiAudit.')


def demo():
    require_user()
    base, source, python = paths()
    if not (base / 'ready.json').is_file() or not python.is_file():
        raise ValueError('Prima premi Prepara NetPwn. Servono git e python3-venv.')
    private_dir(base)
    with (base / 'demo.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        # Reserve-check only: uvicorn still owns binding and reports a race cleanly.
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', PORT))
        process = None
        interrupted = False

        def halt(signum, frame):
            nonlocal interrupted
            interrupted = True
            if process and process.poll() is None:
                os.killpg(process.pid, signal.SIGTERM)

        for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            signal.signal(sig, halt)
        path = base / 'running.json'
        try:
            env = os.environ.copy()
            env['NETPWN_DEMO'] = '1'
            process = subprocess.Popen([str(python), str(source / 'netpwn.py'), '--demo', '--host', '127.0.0.1', '--port', str(PORT)], cwd=source, env=env, start_new_session=True)
            ticks, _, _ = identity(os.getpid())
            path.write_text(json.dumps({'pid': os.getpid(), 'ticks': ticks}), encoding='utf-8')
            print(f'Demo sintetica: http://127.0.0.1:{PORT} - Ctrl+C o Ferma demo per uscire.', flush=True)
            while process.poll() is None and not interrupted:
                time.sleep(.2)
            return process.returncode or 0
        finally:
            if process and process.poll() is None:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
            path.unlink(missing_ok=True)


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['install', 'demo', 'stop'])
    args = parser.parse_args()
    try:
        return {'install': install, 'demo': demo, 'stop': stop}[args.action]() or 0
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        print('NetPwn: ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
