# WiFiAudit 6.0 - specifica

Obiettivo: collegare audit mirato, recupero offline e gestione dei risultati senza promettere il recupero di qualsiasi password.

R1. Procedura Wifite2 opzionale su un solo BSSID, con profili osservazione/audit, anteprima e limiti di tempo; nessun avvio radio durante i test.
R2. Verifica locale delle catture: struttura/formato e, se disponibile, presenza di EAPOL con TShark. Non certificare la validità di un handshake dalla dimensione.
R3. Ripresa offline per fasi: checkpoint dati, hash del file e delle impostazioni, riutilizzo dei potfile; mai eseguire contenuti del checkpoint. I tentativi interrotti ripartono dall'inizio.
R4. Catalogo sessioni e backup ZIP privato, senza seguire symlink o sovrascrivere file esistenti.
R5. Importare da Wifite solo risultati della nuova sessione con BSSID corrispondente. Conservare output originali ed errori.
R6. Avvio opzionale di Sniffnet/wavemon/Wireshark senza renderli obbligatori.
R7. Conservare menu e CLI precedenti. Nessuna installazione o invio a servizi esterni automatico.

Accettazione: test locali di selezione target, scadenza, parser, checkpoint, manomissione input, symlink e backup; PDF e ZIP controllati. Compatibilità radio/GPU: da verificare su Kali.
