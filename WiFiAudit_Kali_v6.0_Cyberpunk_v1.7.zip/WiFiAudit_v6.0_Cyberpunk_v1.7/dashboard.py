#!/usr/bin/env python3
"""Private job history, scan snapshots and read-only Kismet bridge."""
from __future__ import annotations

import csv
from contextlib import contextmanager
import hashlib
import io
import json
import os
from pathlib import Path
import re
import signal
import sqlite3
import subprocess
import sys
import time
import uuid
from urllib.request import Request, build_opener, ProxyHandler, HTTPRedirectHandler
from urllib.error import HTTPError, URLError

ROOT = Path(__file__).resolve().parent
MAC = re.compile(r"^(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$")


def private_dir(path):
    path = Path(path).absolute()
    # Refuse links and other-writable directories, including ancestors.
    for parent in (*reversed(path.parents), path):
        if parent.is_symlink():
            raise ValueError('Collegamenti simbolici non ammessi')
        if not parent.exists():
            parent.mkdir(mode=0o700)
        st = parent.stat()
        if st.st_uid not in (0, os.geteuid()) or st.st_mode & 0o022:
            raise ValueError('Directory non privata o non fidata: ' + str(parent))
    os.chmod(path, 0o700)
    return path


def state_dir():
    return private_dir(Path.home() / '.local' / 'state' / 'wifiaudit-dashboard')


@contextmanager
def connect():
    path = state_dir() / 'history.sqlite3'
    if path.is_symlink():
        raise ValueError('Database non valido')
    fd = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    os.close(fd)
    os.chmod(path, 0o600)
    db = sqlite3.connect(path, timeout=10)
    db.row_factory = sqlite3.Row
    db.executescript('''
      CREATE TABLE IF NOT EXISTS jobs (
        id TEXT PRIMARY KEY, title TEXT NOT NULL, command TEXT NOT NULL,
        status TEXT NOT NULL, created REAL NOT NULL, updated REAL NOT NULL,
        code INTEGER, worker INTEGER);
      CREATE TABLE IF NOT EXISTS snapshots (
        id TEXT PRIMARY KEY, label TEXT NOT NULL, source TEXT NOT NULL,
        created REAL NOT NULL, digest TEXT NOT NULL, data TEXT NOT NULL);
    ''')
    try:
        with db:
            yield db
    finally:
        db.close()


def new_job(title, command, simulated=False):
    ident = uuid.uuid4().hex
    now = time.time()
    with connect() as db:
        db.execute('INSERT INTO jobs VALUES (?,?,?,?,?,?,?,?)',
                   (ident, title[:120], json.dumps(command), 'SIMULATA' if simulated else 'IN_ATTESA', now, now, None, None))
    return ident


def update_job(ident, status, code=None, worker=None):
    with connect() as db:
        db.execute('UPDATE jobs SET status=?, updated=?, code=?, worker=? WHERE id=?',
                   (status, time.time(), code, worker, ident))


def jobs():
    now = time.time()
    with connect() as db:
        db.execute("UPDATE jobs SET status='STATO_SCONOSCIUTO' WHERE status IN ('IN_CORSO','IN_ATTESA') AND updated < ?", (now - 45,))
        rows = db.execute('SELECT * FROM jobs ORDER BY created DESC LIMIT 100').fetchall()
    return [dict(row) | {'command': json.loads(row['command'])} for row in rows]


def run_job(ident):
    if not re.fullmatch('[a-f0-9]{32}', ident):
        return 2
    with connect() as db:
        row = db.execute('SELECT * FROM jobs WHERE id=?', (ident,)).fetchone()
    if not row or row['status'] not in ('IN_ATTESA', 'STATO_SCONOSCIUTO'):
        return 2
    command = json.loads(row['command'])
    if not isinstance(command, list) or not command or not all(isinstance(x, str) for x in command):
        return 2
    process = None
    stopped = False

    def stop(signum, frame):
        nonlocal stopped
        stopped = True
        if process and process.poll() is None:
            try:
                process.send_signal(signal.SIGINT)
            except ProcessLookupError:
                pass

    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, stop)
    update_job(ident, 'IN_CORSO', worker=os.getpid())
    try:
        # Inherit terminal IO. No password/output capture, no shell evaluation.
        process = subprocess.Popen(command, cwd=ROOT)
        while process.poll() is None:
            update_job(ident, 'IN_CORSO', worker=os.getpid())
            time.sleep(1)
        code = process.returncode
        status = 'INTERROTTA' if stopped or code in (130, -2, 129, -1) else ('COMPLETATA' if code == 0 else 'FALLITA')
        update_job(ident, status, code)
        return code if code >= 0 else 128 - code
    except OSError:
        update_job(ident, 'FALLITA', 127)
        print('Impossibile avviare il comando', file=sys.stderr)
        return 127


def read_limited(path, limit=10 * 1024 * 1024):
    path = Path(path).expanduser().absolute()
    if any(x.is_symlink() for x in (path, *path.parents)):
        raise ValueError('Collegamenti simbolici non ammessi')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        import stat
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ValueError('Serve un file regolare')
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError('File troppo grande (limite 10 MiB)')
    return data


def parse_scan(data):
    rows = csv.reader(io.StringIO(data.decode('utf-8-sig', errors='replace')))
    header = None
    networks = {}
    for row in rows:
        row = [cell.strip() for cell in row]
        if row and row[0] == 'Station MAC':
            break
        if row and row[0] == 'BSSID':
            header = {name: idx for idx, name in enumerate(row)}
            continue
        if not header or not row or not MAC.fullmatch(row[0]):
            continue
        def get(name, default=''):
            idx = header.get(name, -1)
            return row[idx] if 0 <= idx < len(row) else default
        bssid = row[0].upper()
        networks[bssid] = {
            'bssid': bssid, 'essid': get('ESSID')[:256], 'channel': get('channel'),
            'security': get('Privacy')[:100], 'cipher': get('Cipher')[:100],
            'auth': get('Authentication')[:100], 'signal': get('Power'),
        }
        if len(networks) > 20000:
            raise ValueError('Troppe reti nel file')
    if header is None or not {'BSSID', 'ESSID', 'Privacy'}.issubset(header):
        raise ValueError('Serve un CSV airodump-ng con intestazioni BSSID, ESSID e Privacy')
    return list(networks.values())


def save_snapshot(label, source, networks, digest):
    ident = uuid.uuid4().hex
    with connect() as db:
        db.execute('INSERT INTO snapshots VALUES (?,?,?,?,?,?)',
                   (ident, str(label)[:120], source, time.time(), digest, json.dumps(networks, ensure_ascii=True)))
    return ident


def import_scan(path):
    if Path(path).suffix.lower() != '.csv':
        raise ValueError('Seleziona un file .csv di airodump-ng')
    data = read_limited(path)
    networks = parse_scan(data)
    ident = save_snapshot(Path(path).name, 'CSV_IMPORTATO', networks, hashlib.sha256(data).hexdigest())
    return {'id': ident, 'networks': len(networks)}


def snapshots():
    with connect() as db:
        rows = db.execute('SELECT * FROM snapshots ORDER BY created DESC LIMIT 100').fetchall()
    result = []
    for row in rows:
        item = dict(row)
        networks = json.loads(item.pop('data'))
        item['networks'] = len(networks)
        result.append(item)
    return result


def snapshot(ident):
    if not re.fullmatch('[a-f0-9]{32}', str(ident)):
        raise ValueError('Snapshot non valido')
    with connect() as db:
        row = db.execute('SELECT * FROM snapshots WHERE id=?', (ident,)).fetchone()
    if not row:
        raise ValueError('Snapshot non trovato')
    item = dict(row)
    item['networks'] = json.loads(item.pop('data'))
    return item


def diff(before, after):
    old = snapshot(before)
    new = snapshot(after)
    a = {x['bssid']: x for x in old['networks']}
    b = {x['bssid']: x for x in new['networks']}
    changed = []
    for key in sorted(a.keys() & b.keys()):
        fields = {f: {'before': a[key].get(f), 'after': b[key].get(f)} for f in ('essid', 'channel', 'security', 'cipher', 'auth', 'signal') if a[key].get(f) != b[key].get(f)}
        if fields:
            changed.append({'bssid': key, 'changes': fields})
    return {'before': old['label'], 'after': new['label'],
            'added': [b[k] for k in sorted(b.keys() - a.keys())],
            'not_observed': [a[k] for k in sorted(a.keys() - b.keys())], 'changed': changed,
            'note': 'Non osservato nella seconda scansione non significa rimosso. BSSID e SSID possono essere falsificati.'}


def session_catalog(root):
    root = Path(root).expanduser().absolute()
    if any(p.is_symlink() for p in (root, *root.parents)):
        raise ValueError('Collegamenti simbolici non ammessi')
    if not root.is_dir():
        raise ValueError('Cartella risultati non trovata o non accessibile')
    result = []
    for folder in sorted(root.glob('session_*'), reverse=True)[:100]:
        if folder.is_symlink() or not folder.is_dir():
            continue
        files = [p for p in folder.iterdir() if p.is_file() and not p.is_symlink()]
        outcome = 'NON_VERIFICATO'
        for name in ('auto_risultato.txt', 'guided_risultato.txt'):
            f = folder / name
            if f.is_file() and not f.is_symlink():
                # Only expose known status labels, never arbitrary lines containing keys.
                text = read_limited(f, 100000).decode(errors='replace')
                match = re.search(r'^Esito: ([A-Z_]+)\s*$', text, re.M)
                allowed = {'TROVATA', 'NON_TROVATA', 'FASI_GIA_COMPLETATE', 'CATTURA_DA_VERIFICARE', 'TROVATA_DA_WIFITE', 'CATTURA_TROVATA', 'NESSUN_HASH_DEL_TARGET', 'NESSUN_TENTATIVO_ESEGUIBILE', 'TEMPO_ESAURITO', 'LIMITI_TEMPO_RAGGIUNTI', 'OUTPUT_DA_VERIFICARE', 'ERRORI_DURANTE_I_TENTATIVI'}
                if match and match[1] in allowed:
                    outcome = match[1]
        result.append({'name': folder.name, 'path': str(folder), 'files': len(files), 'status': outcome,
                       'scans': [str(p) for p in files if p.suffix.lower() == '.csv'],
                       'resume': (folder / 'checkpoint.json').is_file()})
    return result


def hardware_status():
    import shutil
    result = {'interfaces': [], 'monitor': 'NON_VERIFICATO', 'bands': [], 'note': 'Supporto dichiarato dal driver; injection e stabilita non provate.'}
    if shutil.which('ip'):
        try:
            proc = subprocess.run(['ip', '-j', 'link', 'show'], capture_output=True, text=True, timeout=5)
            result['interfaces'] = [{'name': i.get('ifname'), 'state': i.get('operstate')} for i in json.loads(proc.stdout or '[]')]
        except (OSError, ValueError, subprocess.TimeoutExpired):
            pass
    if shutil.which('iw'):
        try:
            proc = subprocess.run(['iw', 'list'], capture_output=True, text=True, timeout=5)
            if proc.returncode == 0:
                result['monitor'] = 'DICHIARATO' if re.search(r'^\s*\* monitor\s*$', proc.stdout, re.M) else 'NON_DICHIARATO'
                result['bands'] = sorted(set(re.findall(r'Band (\d+):', proc.stdout)))
        except (OSError, subprocess.TimeoutExpired):
            pass
    return result


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def kismet_json(endpoint, key, port):
    if endpoint not in ('/system/status.json', '/devices/views/phydot11_accesspoints/last-time/0/devices.json'):
        raise ValueError('Endpoint non consentito')
    if not isinstance(key, str) or len(key) > 4096 or not re.fullmatch(r'[A-Za-z0-9._~-]+', key):
        raise ValueError('Chiave API Kismet non valida')
    port = int(port)
    if not 1024 <= port <= 65535:
        raise ValueError('Porta Kismet non valida')
    req = Request(f'http://127.0.0.1:{port}' + endpoint, headers={'Cookie': 'KISMET=' + key, 'Accept': 'application/json'})
    try:
        with build_opener(ProxyHandler({}), NoRedirect()).open(req, timeout=8) as response:
            data = response.read(4 * 1024 * 1024 + 1)
        if len(data) > 4 * 1024 * 1024:
            raise ValueError('Inventario troppo grande (limite 4 MiB)')
        return json.loads(data)
    except HTTPError as exc:
        raise ValueError(f'Kismet HTTP {exc.code}: verificare API key readonly e versione') from None
    except (URLError, TimeoutError, OSError, json.JSONDecodeError):
        raise ValueError('Kismet non raggiungibile o risposta non valida') from None


def kismet_import(key, port=2501):
    status = kismet_json('/system/status.json', key, port)
    devices = kismet_json('/devices/views/phydot11_accesspoints/last-time/0/devices.json', key, port)
    if not isinstance(status, dict) or not isinstance(devices, list):
        raise ValueError('Formato API Kismet non supportato')
    networks = []
    for item in devices[:20000]:
        if not isinstance(item, dict):
            raise ValueError('Formato dispositivo Kismet non supportato')
        mac = str(item.get('kismet.device.base.macaddr', '')).upper()
        if not MAC.fullmatch(mac):
            continue
        networks.append({'bssid': mac, 'essid': str(item.get('kismet.device.base.name', ''))[:256],
                         'channel': str(item.get('kismet.device.base.channel', ''))[:30],
                         'security': str(item.get('kismet.device.base.crypt', 'NON_VERIFICATO'))[:100],
                         'cipher': '', 'auth': '', 'signal': ''})
    digest = hashlib.sha256(json.dumps(networks, sort_keys=True).encode()).hexdigest()
    ident = save_snapshot('Kismet AP ' + time.strftime('%Y-%m-%d %H:%M'), 'KISMET_READONLY', networks, digest)
    return {'id': ident, 'networks': len(networks), 'status': 'IMPORTATO', 'note': 'Nome dispositivo e campi dichiarati da Kismet; nessuna acquisizione avviata.'}


def report_pdf(ident):
    try:
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.pagesizes import A4
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, LongTable, TableStyle
    except ImportError:
        raise ValueError('Installa python3-reportlab dal Centro installazioni') from None
    from html import escape
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    data = snapshot(ident)
    outdir = private_dir(state_dir() / 'reports')
    output = outdir / ('audit_' + uuid.uuid4().hex + '.pdf')
    styles = getSampleStyleSheet()
    regular = Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
    bold = Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf')
    normal_font, bold_font = 'Helvetica', 'Helvetica-Bold'
    if regular.is_file() and bold.is_file():
        pdfmetrics.registerFont(TTFont('AuditSans', str(regular)))
        pdfmetrics.registerFont(TTFont('AuditSansBold', str(bold)))
        normal_font, bold_font = 'AuditSans', 'AuditSansBold'
    for name in styles.byName:
        styles[name].fontName = bold_font if name.startswith(('Heading', 'Title')) else normal_font
    styles.add(ParagraphStyle(name='SmallCell', parent=styles['BodyText'], fontSize=8, leading=11, wordWrap='CJK'))
    def p(text, style='BodyText'):
        return Paragraph(escape(str(text)), styles[style])
    networks = data['networks']
    story = [p('WiFiAudit - Rapporto di osservazione', 'Title'), Spacer(1, 14),
             p(data['label'], 'Heading2'),
             p('Generato: ' + time.strftime('%Y-%m-%d %H:%M:%S %z')),
             p('Fonte: ' + data['source'] + ' | Reti osservate: ' + str(len(networks))),
             p('SHA-256 fonte normalizzata o file: ' + data['digest']), Spacer(1, 14),
             p('Evidenze e limiti', 'Heading2'),
             p('Il rapporto descrive osservazioni importate. Non dimostra un accesso riuscito, la robustezza di una password o la proprieta di un dispositivo. Non contiene password. I dati identificativi degli AP sono riservati.'),
             Spacer(1, 14)]
    rows = [[p(x, 'SmallCell') for x in ('BSSID', 'ESSID / nome', 'Canale', 'Sicurezza dichiarata')]]
    for item in networks[:2000]:
        rows.append([p(item.get(k, ''), 'SmallCell') for k in ('bssid', 'essid', 'channel', 'security')])
    table = LongTable(rows, colWidths=[110, 140, 45, 200], repeatRows=1, hAlign='LEFT')
    table.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,0), colors.HexColor('#c6edf1')),
                               ('VALIGN', (0,0), (-1,-1), 'TOP'),
                               ('GRID', (0,0), (-1,-1), .3, colors.lightgrey),
                               ('BOTTOMPADDING', (0,0), (-1,-1), 7)]))
    story += [p('Tabella limitata alle prime 2000 reti osservate.'), table, Spacer(1, 16), p('Azioni da valutare', 'Heading2'),
              p('Verificare manualmente le reti aperte e WEP; preferire WPA2-AES o WPA3 quando supportati; controllare WPS, firmware, segmentazione ospiti e gestione remota. Associare ogni rilievo a una prova prima di assegnare una gravita.')]
    def footer(canvas, doc):
        canvas.setFont(normal_font, 8)
        canvas.drawString(50, 25, 'RISERVATO - WiFiAudit | pagina ' + str(doc.page))
    fd = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    os.close(fd)
    try:
        SimpleDocTemplate(str(output), pagesize=A4, leftMargin=50, rightMargin=50, topMargin=45, bottomMargin=45).build(story, onFirstPage=footer, onLaterPages=footer)
    except Exception:
        output.unlink(missing_ok=True)
        raise
    return str(output)


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == 'run':
        raise SystemExit(run_job(sys.argv[2]))
    raise SystemExit('Uso interno: dashboard.py run ID')
