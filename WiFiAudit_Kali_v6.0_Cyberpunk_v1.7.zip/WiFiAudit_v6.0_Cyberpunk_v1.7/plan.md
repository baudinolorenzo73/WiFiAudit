# Piano

1. Conservare la base 5.5 e aggiungere un modulo Bash e un helper Python con sola libreria standard.
2. Usare Wifite già installato, verificando le opzioni tramite help locale. La procedura opera in una cartella nuova e ha un timeout.
3. Usare JSON per checkpoint e inventario; SHA-256 collega la ripresa all'input e alle impostazioni. Un lock impedisce riprese concorrenti sulla stessa sessione.
4. Mantenere i segreti nei file privati. ZIP con manifest SHA-256, senza cifratura dichiarata.
5. Verificare con motori simulati e documentare separatamente ciò che richiede hardware.

Ripristino: nessuna migrazione distruttiva; la versione 5.5 rimane disponibile nella cronologia del file. I nuovi moduli non modificano i vecchi risultati.
