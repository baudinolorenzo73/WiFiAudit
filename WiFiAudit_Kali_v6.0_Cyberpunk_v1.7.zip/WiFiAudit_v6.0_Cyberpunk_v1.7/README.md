# WiFiAudit 6.0 - Kali Linux

## Dashboard Cyberpunk 1.7

Integrazione opzionale NetPwn: nella sezione **NETPWN // DEMO LAB** premi Prepara NetPwn, Avvia demo e Apri dashboard. L'ambiente Python è separato, la revisione GitHub è fissa e la demo gira senza sudo sulla porta locale 8877. Ferma demo arresta soltanto il processo verificato della demo. I dettagli e i passaggi per il collaudo Kali sono in `GUIDA_NETPWN.md`. Il PDF conserva la documentazione del pannello 1.6; la nuova guida descrive l'aggiunta 1.7.

Nuove sezioni: attività con stato e durata, simulazione degli avvii, storico e confronto di CSV airodump-ng, rapporto PDF delle osservazioni, lettura API Kismet readonly, capacità dichiarate dal driver, risorse web e catalogo esteso degli strumenti Kali. Premi **Carica esempio dimostrativo** per provare confronto e PDF senza hardware, anche su GitHub Pages.

Per generare PDF locali installare `python3-reportlab` dal centro installazioni. Il PDF di esempio sintetico è già incluso. Dettagli e limiti in `docs/dashboard_spec.md`.

## Pannello HTML per Kali

Avvia come utente normale, dalla cartella estratta:

```bash
chmod +x avvia_pannello.sh
./avvia_pannello.sh
```

Si apre un pannello cyberpunk locale nel browser. Quando una funzione richiede privilegi, la password `sudo` viene chiesta nel terminale di Kali e non viene salvata dal pannello. Include una guida ai comandi, 16 utilità, più un centro installazioni per Wi-Fi, ZIP/7z/RAR, PDF, DOCX, sistema e laboratorio. L'installazione dal pannello è limitata a pacchetti predefiniti dei repository configurati.

La versione 1.6 usa percorsi relativi ed è compatibile anche con GitHub Project Pages. Sul sito pubblicato funziona come anteprima PWA, guida e pagina di download; il browser remoto non può eseguire `sudo` o Bash. Le azioni operative restano disponibili avviando localmente `./avvia_pannello.sh` su Kali.

La toolchain comprende anche hcxdumptool/hcxtools, Reaver/Pixiewps, Wifite e tcpdump. Airgeddon, Bettercap, Fern, MDK4, Wifiphisher e WiFiPumpkin3 sono nel gruppo **Laboratorio avanzato**: il pannello può installarli dai repository Kali, ma non genera campagne MITM, portali di phishing, flood o attacchi massivi. Pyrit non è incluso perché Kali lo ha rimosso nel 2020.

Per aggiungere un collegamento al menu applicazioni:

```bash
./avvia_pannello.sh --install
```

Estrarre l'intero ZIP in una cartella: `wifiaudit.sh`, `wifiaudit_v6.sh` e `wifiaudit_tools.py` devono rimanere insieme. La versione 6 non è un singolo script autosufficiente.

```bash
bash wifiaudit.sh --menu
bash wifiaudit.sh --self-test
sudo bash wifiaudit.sh --menu
```

## Nuove funzioni

- Menu iniziale 9: procedura Wifite per un solo BSSID, con interfaccia obbligatoria, anteprima e conferma.
- Osservazione: passa `--nodeauths --no-wps --no-pmkid`. Audit attivo: permette le tecniche WPA/WPS implementate dal Wifite locale. L'effettivo comportamento dipende dal programma installato.
- Wifite viene eseguito in una cartella nuova, con limite di tempo e senza opzioni di upload o selezione indiscriminata. L'help locale viene controllato prima dell'avvio.
- Il programma importa solo chiavi dal `cracked.json` creato nella nuova cartella, per il BSSID scelto. Le chiavi sono dichiarate dal motore esterno, non riverificate mediante una nuova connessione Wi-Fi.
- Se è stata prodotta una cattura, tenta la conversione con hcxtools e filtra gli hash per il solo BSSID scelto prima del recupero offline con budget separato. Se non è possibile ottenere hash del target, conserva la cattura da verificare. I percorsi delle due sessioni sono collegati in `offline_link.txt`.
- Menu iniziale 10 / suite 15: verifica catture, catalogo, ripresa per fasi, backup ZIP, avvio opzionale di Sniffnet/Wireshark/wavemon.
- I checkpoint confrontano input, wordlist e impostazioni. Le fasi completate sono saltate; quelle interrotte ripartono dall'inizio. Non è una ripresa della posizione esatta del motore.
- Il backup contiene dati sensibili, ha permessi 600 e un manifest SHA-256, ma NON è cifrato. Non segue link simbolici e non sovrascrive file.

## Requisiti

Per helper, catalogo, verifica, backup e checkpoint: Python 3.11+ (sola libreria standard), Bash, coreutils e flock. Per il recupero: John Jumbo e/o hashcat secondo il formato. Per la procedura radio: Wifite già installato e relative dipendenze; root e scheda compatibile.

Su Kali Wifite può essere installato esplicitamente con `sudo apt install wifite`. Lo script non installa pacchetti. L'installazione base non garantisce le funzioni del ramo GitHub più recente.

## CLI

```bash
bash wifiaudit.sh --inspect /percorso/cattura.cap
bash wifiaudit.sh --catalog /percorso/wifiaudit_results
bash wifiaudit.sh --resume /percorso/session_...
bash wifiaudit.sh --backup-session /percorso/session_... /percorso/backup.zip
sudo bash wifiaudit.sh --guided
```

Le opzioni v6 sono esclusive. Per riprendere, servono l'input originale e le stesse impostazioni; le configurazioni possono essere caricate dal pannello o dal percorso privato predefinito. Non modificare checkpoint o potfile manualmente.

## Risultati

La procedura guidata produce `guided_scope.txt`, `wifite.log`, `guided_risultato.txt`, `passwords.tsv`, un report HTML e, se avviato il recupero, `offline_link.txt`. Le sessioni offline producono anche `checkpoint.json`, `auto_tentativi.tsv`, `auto_risultato.txt` e potfile privati. Il report HTML del recupero offline può non contenere statistiche delle reti: in quel caso il rischio è NON_VALUTATO.

Un risultato TROVATA significa che è stata importata almeno una chiave dal motore. NON_TROVATA significa soltanto nessun risultato con i tentativi effettuati. Lo stato 0 di Wifite da solo non implica successo. Un header PCAP o frame EAPOL presenti non dimostrano un handshake completo e valido.

## Test e limiti

```bash
python3 tests/test_v6.py
bash -n wifiaudit.sh
bash -n wifiaudit_v6.sh
```

I test radio/GPU sono simulati: nessuna rete è stata attaccata durante lo sviluppo. Catture, conversioni, versioni reali di John/hashcat/Wifite, driver, ripristino dopo crash e compatibilità hardware richiedono un laboratorio autorizzato. Wifite gestisce la propria interfaccia; in caso di arresto forzato può essere necessario verificarla manualmente. Nessun software può garantire il recupero di una password robusta.

## Riferimenti

- https://www.kali.org/tools/wifite/
- https://github.com/kimocoder/wifite2
- https://github.com/ZerBea/hcxtools
- https://github.com/hashcat/hashcat
- https://github.com/openwall/john
- https://github.com/GyulyVGC/sniffnet

L'integrazione richiama programmi esterni: non incorpora il loro codice. Il generatore `genera_manuale.sh` fornito inizialmente non è usato.
