# WiFiAudit 6.0 extensions, sourced only by the main script.
GUIDED_SECONDS=900
GUIDED_PROFILE=passive
AUTO_RESUME_DIR=""
LAST_AUTO_DIR=""
LAST_AUTO_STATUS=""

v6_helper(){
  command -v python3 &>/dev/null || { err "Installa python3 per questa funzione"; return 2; }
  [[ -f "$SCRIPT_DIR/wifiaudit_tools.py" && ! -L "$SCRIPT_DIR/wifiaudit_tools.py" ]] || {
    err "Manca wifiaudit_tools.py: estrai il pacchetto completo"; return 2;
  }
  python3 "$SCRIPT_DIR/wifiaudit_tools.py" "$@"
}

v6_checkpoint_begin(){
  WORDLIST="$WORDLIST" JOHN_RULES="$JOHN_RULES" JOHN_MASK="$JOHN_MASK" HC_MASK="$HC_MASK" AUTO_USE_MASK="$AUTO_USE_MASK" \
    v6_helper begin "$OUTDIR" --input "$1" --resume "$AUTO_RESUME_DIR" > "$OUTDIR/checkpoint_setup.json"
}

v6_resume(){
  local source="$1" input="" root="${RESULTS_ROOT:-$OUTDIR}"
  local AUTO_INPUT="" AUTO_RESUME_DIR="$source" lockfd
  trusted_directory "$source" || { err "Sessione non fidata"; return 2; }
  [[ ! -L "$source/.resume.lock" ]] || return 2
  umask 077
  exec {lockfd}>"$source/.resume.lock" || return 2
  flock -n "$lockfd" || { err "Ripresa gia in corso"; exec {lockfd}>&-; return 2; }
  local recovered="$source/.resume_input_$$"
  # File esclusivo: nessuna esecuzione del contenuto del checkpoint.
  if ! (set -C; v6_helper resume-input "$source" > "$recovered"); then
    exec {lockfd}>&-; return 2
  fi
  IFS= read -r -d '' input < "$recovered" || true
  rm -f -- "$recovered"
  [[ -n "$input" ]] || { exec {lockfd}>&-; return 2; }
  auto_recover "$input"; local rc=$?
  exec {lockfd}>&-
  return "$rc"
}

v6_tools_menu(){
  local choice tool
  printf '\n1) Sniffnet  2) Wireshark  3) wavemon  0) Indietro\n'
  read -rp 'Scelta: ' choice || return 0
  case "$choice" in 1) tool=sniffnet ;; 2) tool=wireshark ;; 3) tool=wavemon ;; *) return 0 ;; esac
  command -v "$tool" &>/dev/null || { err "$tool non installato; consulta la diagnostica"; return 2; }
  if [[ $EUID -eq 0 && "$tool" != wavemon ]]; then
    info "Apri l'app grafica da una sessione utente normale: $tool"; return 0
  fi
  "$tool"
}

v6_session_menu(){
  local choice path destination
  while :; do
    printf '\nSESSIONI E FILE\n1) Catalogo  2) Verifica cattura/hash\n3) Riprendi recupero offline  4) Backup ZIP sessione\n5) Strumenti grafici/diagnostici  0) Indietro\n'
    read -rp 'Scelta: ' choice || return 0
    case "$choice" in
      1) v6_helper catalog "${RESULTS_ROOT:-$OUTDIR}" || true ;;
      2) read -rp 'File locale: ' path; v6_helper inspect "$path" || true ;;
      3) read -rp 'Cartella sessione con checkpoint.json: ' path; v6_resume "$path" || true ;;
      4)
        read -rp 'Cartella della sessione: ' path
        read -rp 'Nuovo file ZIP fuori dalla sessione: ' destination
        info "Il backup include catture, log e risultati; ZIP non cifrato."
        v6_helper backup "$path" --output "$destination" || true ;;
      5) v6_tools_menu || true ;;
      0) return 0 ;;
    esac
  done
}

v6_require_root(){ [[ $EUID -eq 0 ]]; }

v6_guided(){
  [[ -z "$SESSION_ID" ]] || { err "Esci dalla suite prima di affidare la scheda a Wifite"; return 2; }
  v6_require_root || { err "Avvia sudo bash wifiaudit.sh --menu e scegli la procedura guidata"; return 2; }
  command -v wifite &>/dev/null || { err "Wifite non installato. Su Kali: sudo apt install wifite"; return 2; }
  command -v timeout &>/dev/null || return 2
  local key answer help profile bssid iface root="${RESULTS_ROOT:-$OUTDIR}"
  local OUTDIR="$root" RESULTS_ROOT="" LOG_FILE="" PASSWORDS_FILE="" ARCHIVE_FILE="" SESSION_ID=""
  local -a args=() fields=()
  for key in TARGET_BSSID TARGET_CHAN TARGET_ESSID; do edit_parameter "$key" || return 2; done
  [[ "$TARGET_BSSID" =~ ^([[:xdigit:]]{2}:){5}[[:xdigit:]]{2}$ ]] || { err "Serve un BSSID valido"; return 2; }
  bssid="$TARGET_BSSID"
  read -rp 'Interfaccia fisica obbligatoria (es. wlan1): ' iface || return 2
  [[ "$iface" =~ ^[a-zA-Z0-9_.:-]+$ ]] || return 2
  printf '1) Osservazione: attende riconnessioni naturali; disabilita WPS, PMKID e deauth\n'
  printf '2) Audit attivo: consente le tecniche WPA/WPS del programma; puo scollegare client\n'
  read -rp 'Profilo [1]: ' profile || return 2
  case "${profile:-1}" in 1) profile=passive ;; 2) profile=active ;; *) return 2 ;; esac
  read -rp "Limite fase Wifite in secondi [$GUIDED_SECONDS]: " answer || return 2
  [[ -z "$answer" ]] || GUIDED_SECONDS="$answer"
  [[ "$GUIDED_SECONDS" =~ ^[1-9][0-9]{0,4}$ ]] || return 2
  help=$(timeout -k 2s 10s wifite -h -v 2>&1) || { err "Help Wifite non leggibile"; return 2; }
  for key in --dict --wpa; do
    [[ "$help" == *"$key"* ]] || { err "Versione Wifite incompatibile: manca $key"; return 2; }
  done
  grep -Eq '(^|[[:space:]])-b([[:space:],]|$)' <<< "$help" || { err "Filtro BSSID non riconosciuto nell'help: avvio rifiutato"; return 2; }
  args=(-b "$bssid" -i "$iface" --wpa)
  [[ -z "$TARGET_CHAN" ]] || args+=(-c "$TARGET_CHAN")
  if [[ -r "$WORDLIST" && -s "$WORDLIST" ]]; then
    args+=(--dict "$WORDLIST")
  else
    [[ "$help" == *--skip-crack* ]] || return 2
    args+=(--skip-crack)
    info "Wordlist assente: Wifite raccogliera soltanto materiale; il recupero offline resta separato."
  fi
  if [[ "$profile" == passive ]]; then
    for key in --nodeauths --no-wps --no-pmkid; do
      [[ "$help" == *"$key"* ]] || { err "Profilo osservazione non supportato: manca $key"; return 2; }
      args+=("$key")
    done
  fi
  printf 'Rete autorizzata: %s | interfaccia: %s | profilo: %s | limite: %ss\n' "$bssid" "$iface" "$profile" "$GUIDED_SECONDS"
  printf 'Comando: wifite '; printf '%q ' "${args[@]}"; printf '\n'
  read -rp 'Avviare questa prova sulla rete autorizzata? [s/N] ' answer || return 2
  [[ "${answer,,}" == s ]] || return 0
  umask 077
  init_outputs || return 2
  printf 'BSSID=%s\nINTERFACCIA=%s\nPROFILO=%s\n' "$bssid" "$iface" "$profile" > "$OUTDIR/guided_scope.txt"
  local rc status=NESSUN_RISULTATO_IMPORTABILE input offline_rc
  # Tutti i risultati relativi di Wifite appartengono a una nuova cartella.
  # Non vengono passati --kill, --infinite, --wpasec o argomenti liberi.
  (cd "$OUTDIR" && timeout -s INT -k 10s "${GUIDED_SECONDS}s" wifite "${args[@]}") 2>&1 | tee "$OUTDIR/wifite.log"
  rc=${PIPESTATUS[0]}
  if [[ -f "$OUTDIR/cracked.json" && ! -L "$OUTDIR/cracked.json" ]]; then
    if v6_helper import-wifite "$OUTDIR/cracked.json" --bssid "$bssid" > "$OUTDIR/import_results.bin"; then
      mapfile -d '' -t fields < "$OUTDIR/import_results.bin"
      local i
      for ((i=0; i+1<${#fields[@]}; i+=2)); do
        TARGET_ESSID="${fields[$i]}"
        log_found_password PASSWORD "${fields[$((i+1))]}" "$OUTDIR/cracked.json" wifite || return 2
        status=TROVATA_DA_WIFITE
      done
    else status=RISULTATI_DA_VERIFICARE; fi
  fi
  if [[ "$status" == NESSUN_RISULTATO_IMPORTABILE ]]; then
    input=""
    IFS= read -r -d '' input < <(find "$OUTDIR" -maxdepth 3 -type f \( -name '*.22000' -o -name '*.cap' -o -name '*.pcapng' \) -print0) || true
    if [[ -n "$input" ]]; then
      local raw_hash="$input"
      if [[ "$input" != *.22000 ]]; then
        raw_hash="$OUTDIR/guided_raw.22000"
        if command -v hcxpcapngtool &>/dev/null; then
          timeout -k 5s 30s hcxpcapngtool -o "$raw_hash" "$input" >>"$LOG_FILE" 2>&1 || true
        fi
      fi
      if [[ -s "$raw_hash" ]] && v6_helper filter-22000 "$raw_hash" --bssid "$bssid" --output "$OUTDIR/target_only.22000" >>"$LOG_FILE"; then
        if [[ -s "$OUTDIR/target_only.22000" ]]; then
          info "Hash del solo BSSID selezionato: recupero offline, budget separato ${AUTO_SECONDS}s"
          auto_recover "$OUTDIR/target_only.22000"; offline_rc=$?
          printf 'Sessione offline: %s\nEsito offline: %s\n' "$LAST_AUTO_DIR" "$LAST_AUTO_STATUS" > "$OUTDIR/offline_link.txt"
          status="CATTURA_${LAST_AUTO_STATUS:-DA_VERIFICARE}"
        else status=NESSUN_HASH_DEL_TARGET; fi
      else status=CATTURA_DA_VERIFICARE; fi
    elif (( rc == 124 || rc == 137 )); then status=TEMPO_ESAURITO
    elif (( rc != 0 )); then status=ERRORE_WIFITE; fi
  fi
  printf 'Esito: %s\nBSSID: %s\nStato Wifite: %d\nLog: %s\n' "$status" "$bssid" "$rc" "$OUTDIR/wifite.log" > "$OUTDIR/guided_risultato.txt"
  generate_html_report > "$OUTDIR/percorso_report.txt" || true
  info "Esito: $status | riepilogo: $OUTDIR/guided_risultato.txt"
  [[ "$status" == TROVATA_DA_WIFITE || "$status" == CATTURA_TROVATA ]] && return 0
  return 1
}

# Return 99 only when this is not a v6 command, so the old parser continues.
v6_dispatch(){
  local command="${1:-}"
  case "$command" in
    --inspect|--catalog|--resume|--backup-session|--guided) ;;
    *) return 99 ;;
  esac
  if [[ "$command" == --resume || "$command" == --guided ]]; then
    [[ ! -e "$CONFIG_FILE" ]] || safe_source "$CONFIG_FILE" || return 2
  fi
  case "$command" in
    --guided) (( $# == 1 )) || return 2; v6_guided ;;
    --inspect|--catalog) (( $# == 2 )) || return 2; v6_helper "${command#--}" "$2" ;;
    --resume) (( $# == 2 )) || return 2; v6_resume "$2" ;;
    --backup-session) (( $# == 3 )) || return 2; v6_helper backup "$2" --output "$3" ;;
  esac
}
