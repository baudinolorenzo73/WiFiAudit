#!/usr/bin/env python3
"""Pannello locale per avviare WiFiAudit su Kali senza conservare password sudo."""

from __future__ import annotations

import argparse
import json
import os
import secrets
import shlex
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
import dashboard


APP_VERSION = "1.7.0"
ROOT = Path(__file__).resolve().parent
CORE = ROOT / "wifiaudit.sh"
MANUAL = ROOT / "Manuale_wifiaudit_v6.0_Kali.pdf"
RESULTS = Path.home() / "wifiaudit_results"
STATIC_FILES = {
    "/app.css": (ROOT / "app.css", "text/css; charset=utf-8"),
    "/app.js": (ROOT / "app.js", "text/javascript; charset=utf-8"),
    "/dashboard-ui.js": (ROOT / "dashboard-ui.js", "text/javascript; charset=utf-8"),
    "/manifest.webmanifest": (ROOT / "manifest.webmanifest", "application/manifest+json"),
    "/icons/icon.svg": (ROOT / "icons/icon.svg", "image/svg+xml"),
    "/icons/icon-192.png": (ROOT / "icons/icon-192.png", "image/png"),
    "/icons/icon-512.png": (ROOT / "icons/icon-512.png", "image/png"),
    "/Rapporto_esempio_DEMO.pdf": (ROOT / "Rapporto_esempio_DEMO.pdf", "application/pdf"),
}
CAPTURE_SUFFIXES = {".cap", ".pcap", ".pcapng", ".22000", ".hccapx", ".john"}
TERMINALS = ("x-terminal-emulator", "xfce4-terminal", "qterminal", "konsole", "gnome-terminal", "mate-terminal")
UTILITIES: dict[str, dict[str, Any]] = {
    "aircrack": {"label": "Aircrack-ng", "command": "aircrack-ng", "package": "aircrack-ng", "gui": False, "args": ["--help"]},
    "kismet": {"label": "Kismet", "command": "kismet", "package": "kismet", "gui": False, "args": []},
    "hashcat": {"label": "Hashcat", "command": "hashcat", "package": "hashcat", "gui": False, "args": ["--help"]},
    "john": {"label": "John the Ripper", "command": "john", "package": "john", "gui": False, "args": ["--help"]},
    "hydra": {"label": "Hydra", "command": "hydra", "package": "hydra", "gui": False, "args": ["-h"]},
    "nmap": {"label": "Nmap", "command": "nmap", "package": "nmap", "gui": False, "args": ["--help"]},
    "doublecmd": {"label": "Double Commander", "command": "doublecmd", "package": "doublecmd-gtk", "gui": True},
    "krusader": {"label": "Krusader", "command": "krusader", "package": "krusader", "gui": True},
    "mc": {"label": "Midnight Commander", "command": "mc", "package": "mc", "gui": False},
    "wireshark": {"label": "Wireshark", "command": "wireshark", "package": "wireshark", "gui": True},
    "wavemon": {"label": "Wavemon", "command": "wavemon", "package": "wavemon", "gui": False},
    "sniffnet": {"label": "Sniffnet", "command": "sniffnet", "package": None, "gui": True},
    "wifite": {"label": "Wifite (guida)", "command": "wifite", "package": "wifite", "gui": False, "args": ["--help"]},
    "tcpdump": {"label": "tcpdump (guida)", "command": "tcpdump", "package": "tcpdump", "gui": False, "args": ["--help"]},
    "pixiewps": {"label": "Pixiewps (guida)", "command": "pixiewps", "package": "pixiewps", "gui": False, "args": ["--help"]},
    "bettercap": {"label": "Bettercap (guida)", "command": "bettercap", "package": "bettercap", "gui": False, "args": ["-h"]},
}
PACKAGE_GROUPS: dict[str, dict[str, Any]] = {
    "wifi": {
        "label": "WiFiAudit completo",
        "description": "Radio, catture, conversione, recupero e report.",
        "packages": {
            "aircrack-ng": "Suite 802.11",
            "hcxdumptool": "Acquisizione PMKID/EAPOL",
            "hcxtools": "Conversione catture",
            "hashcat": "Recupero GPU/CPU",
            "john": "John the Ripper",
            "reaver": "Verifica WPS",
            "pixiewps": "Verifica offline WPS Pixie Dust",
            "crunch": "Generazione wordlist",
            "wifite": "Procedura guidata",
            "tshark": "Analisi da terminale",
            "macchanger": "Cambio MAC opzionale",
            "hostapd": "Access point di laboratorio",
            "dnsmasq": "DHCP/DNS di laboratorio",
            "iptables": "Regole di rete",
            "tcpdump": "Analisi catture da terminale",
        },
    },
    "archives": {
        "label": "Archivi ZIP / 7z / RAR",
        "description": "Creazione, estrazione e controllo degli archivi più comuni.",
        "packages": {
            "zip": "Crea archivi ZIP",
            "unzip": "Estrae file ZIP",
            "7zip": "Archivi 7z ad alta compressione",
            "unar": "Estrae RAR, 7z, CAB, ISO e altri formati",
        },
    },
    "pdf": {
        "label": "PDF",
        "description": "Lettura, informazioni, conversione, unione e riparazione.",
        "packages": {
            "poppler-utils": "pdfinfo, pdftotext, pdfimages e pdfunite",
            "qpdf": "Ispezione e trasformazione PDF",
            "ghostscript": "Conversione e ottimizzazione",
            "evince": "Visualizzatore grafico",
        },
    },
    "documents": {
        "label": "DOCX e documenti",
        "description": "Apertura, modifica e conversione di Word e documenti testuali.",
        "packages": {
            "libreoffice-writer": "Apre e modifica DOC/DOCX",
            "pandoc": "Conversione tra formati",
            "antiword": "Estrazione testo da vecchi DOC",
        },
    },
    "files": {
        "label": "Gestione file",
        "description": "File manager a due pannelli in stile Total Commander.",
        "packages": {
            "doublecmd-gtk": "Double Commander grafico",
            "krusader": "File manager KDE a due pannelli",
            "mc": "Midnight Commander da terminale",
        },
    },
    "system": {
        "label": "Sistema e sviluppo",
        "description": "Download, JSON, finestre di dialogo, test e script.",
        "packages": {
            "git": "Repository e aggiornamenti",
            "curl": "Download e API",
            "wget": "Download da terminale",
            "jq": "Lettura JSON",
            "zenity": "Finestre grafiche per script",
            "xclip": "Appunti X11",
            "python3": "Runtime del pannello",
            "python3-venv": "Ambienti Python isolati",
            "python3-pip": "Gestione pacchetti Python",
            "shellcheck": "Controllo script Bash",
            "bats": "Test automatici Bash",
            "python3-reportlab": "Rapporti PDF della dashboard",
            "fonts-dejavu-core": "Caratteri incorporati nei PDF",
            "iw": "Capacità e interfacce wireless",
            "iproute2": "Stato delle interfacce di rete",
        },
    },
    "network": {
        "label": "Analisi e rete",
        "description": "Monitoraggio wireless, inventario host, pacchetti e verifica servizi autorizzata.",
        "packages": {
            "kismet": "Rilevamento passivo e WIDS",
            "nmap": "Inventario host, porte e servizi",
            "wireshark": "Analisi grafica delle catture",
            "hydra": "Verifica credenziali dei servizi autorizzati",
        },
    },
    "advanced": {
        "label": "Laboratorio avanzato",
        "description": "Strumenti potenti installabili, senza workflow di attacco automatico nel pannello.",
        "packages": {
            "airgeddon": "Framework Bash per laboratori wireless",
            "bettercap": "Ricognizione e MITM in ambienti autorizzati",
            "fern-wifi-cracker": "Interfaccia grafica di audit Wi-Fi",
            "mdk4": "Test di robustezza 802.11 ad alto impatto",
            "wifiphisher": "Rogue AP e simulazioni di phishing autorizzate",
            "wifipumpkin3": "Framework rogue AP per laboratorio",
        },
    },
}
ALLOWED_PACKAGES = frozenset(
    package
    for group in PACKAGE_GROUPS.values()
    for package in group["packages"]
)


class LaunchError(RuntimeError):
    pass


def command_exists(name: str) -> bool:
    return shutil.which(name) is not None


def require_package() -> None:
    if not (ROOT / 'netpwn_bridge.py').is_file():
        raise LaunchError('Pacchetto incompleto: manca netpwn_bridge.py')
    required = (CORE, ROOT / "wifiaudit_v6.sh", ROOT / "wifiaudit_tools.py", ROOT / 'dashboard.py', ROOT / 'index.html', ROOT / 'app.css', ROOT / 'app.js', ROOT / 'dashboard-ui.js')
    missing = [p.name for p in required if not p.is_file()]
    if missing:
        raise LaunchError("Pacchetto incompleto: manca " + ", ".join(missing))


def safe_existing_file(value: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise LaunchError("Indica il percorso completo della cattura")
    raw = Path(value.strip()).expanduser()
    if raw.is_symlink():
        raise LaunchError("I collegamenti simbolici non sono accettati")
    try:
        path = raw.resolve(strict=True)
    except (FileNotFoundError, OSError) as exc:
        raise LaunchError("File non trovato") from exc
    if not path.is_file() or path.suffix.lower() not in CAPTURE_SUFFIXES:
        raise LaunchError("Formato non supportato: cap, pcap, pcapng, 22000, hccapx o john")
    return path


def safe_session_dir(value: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise LaunchError("Indica la cartella session_* da riprendere")
    raw = Path(value.strip()).expanduser()
    if raw.is_symlink():
        raise LaunchError("I collegamenti simbolici non sono accettati")
    try:
        path = raw.resolve(strict=True)
    except (FileNotFoundError, OSError) as exc:
        raise LaunchError("Cartella sessione non trovata") from exc
    if not path.is_dir() or not path.name.startswith("session_"):
        raise LaunchError("Seleziona una cartella il cui nome inizi con session_")
    return path


def clamp_seconds(value: Any) -> int:
    try:
        seconds = int(value)
    except (TypeError, ValueError) as exc:
        raise LaunchError("La durata deve essere un numero intero") from exc
    if not 60 <= seconds <= 86400:
        raise LaunchError("La durata deve essere compresa tra 60 e 86400 secondi")
    return seconds


def build_action(payload: dict[str, Any]) -> tuple[list[str], bool, str]:
    action = payload.get("action")
    base = ["bash", str(CORE)]
    if action in {'netpwn_install', 'netpwn_demo', 'netpwn_stop'}:
        verb = {'netpwn_install': 'install', 'netpwn_demo': 'demo', 'netpwn_stop': 'stop'}[action]
        return [sys.executable, str(ROOT / 'netpwn_bridge.py'), verb], False, 'NetPwn ' + verb
    if action == "menu":
        return base + ["--menu"], True, "Menu completo"
    if action == "guided":
        return base + ["--guided"], True, "Procedura guidata singolo AP"
    if action == "doctor":
        return base + ["--doctor"], False, "Diagnostica"
    if action == "selftest":
        return base + ["--self-test"], False, "Autotest"
    if action == "catalog":
        return base + ["--catalog", str(RESULTS)], False, "Catalogo sessioni"
    if action == "inspect":
        capture = safe_existing_file(str(payload.get("path", "")))
        return base + ["--inspect", str(capture)], False, "Ispezione cattura"
    if action == "recover":
        capture = safe_existing_file(str(payload.get("path", "")))
        seconds = clamp_seconds(payload.get("seconds", 600))
        return base + ["--auto-recover", str(capture), "--auto-seconds", str(seconds)], True, "Recupero offline"
    if action == "resume":
        session = safe_session_dir(str(payload.get("path", "")))
        return base + ["--resume", str(session)], True, "Ripresa sessione"
    if action == "install_utility":
        utility = utility_from_payload(payload)
        package = utility.get("package")
        if not package:
            raise LaunchError("Installazione automatica non disponibile per questa utilità")
        if not command_exists("apt-get"):
            raise LaunchError("apt-get non è disponibile")
        return ["apt-get", "install", "-y", str(package)], True, f"Installazione {utility['label']}"
    if action == "apt_update":
        if not command_exists("apt-get"):
            raise LaunchError("apt-get non è disponibile")
        return ["apt-get", "update"], True, "Aggiornamento indici APT"
    if action == "install_packages":
        requested = payload.get("packages")
        if not isinstance(requested, list) or not requested or len(requested) > len(ALLOWED_PACKAGES):
            raise LaunchError("Selezione pacchetti non valida")
        if not all(isinstance(item, str) and item in ALLOWED_PACKAGES for item in requested):
            raise LaunchError("La selezione contiene un pacchetto non consentito")
        if not command_exists("apt-get"):
            raise LaunchError("apt-get non è disponibile")
        unique = list(dict.fromkeys(requested))
        return ["apt-get", "install", "-y", *unique], True, f"Installazione {len(unique)} pacchetti"
    raise LaunchError("Azione non consentita")


def utility_from_payload(payload: dict[str, Any]) -> dict[str, Any]:
    utility_id = payload.get("utility")
    if not isinstance(utility_id, str) or utility_id not in UTILITIES:
        raise LaunchError("Utilità non consentita")
    return UTILITIES[utility_id]


def find_terminal() -> str:
    for name in TERMINALS:
        found = shutil.which(name)
        if found:
            return found
    raise LaunchError("Nessun emulatore di terminale trovato")


def make_job(argv: list[str], needs_sudo: bool, title: str) -> Path:
    state = Path.home() / ".cache" / "wifiaudit-launcher" / "jobs"
    dashboard.private_dir(state)
    now = time.time()
    for old_job in state.glob("job_*.sh"):
        try:
            if old_job.is_file() and not old_job.is_symlink() and now - old_job.stat().st_mtime > 604800:
                old_job.unlink()
        except OSError:
            pass
    fd, name = tempfile.mkstemp(prefix="job_", suffix=".sh", dir=state)
    path = Path(name)
    command = (["sudo", "-k", "--"] if needs_sudo else []) + argv
    quoted = " ".join(shlex.quote(part) for part in command)
    ident = dashboard.new_job(title, command)
    worker = ' '.join(shlex.quote(x) for x in [sys.executable, str(ROOT / 'dashboard.py'), 'run', ident])
    body = (
        "#!/usr/bin/env bash\n"
        "set -uo pipefail\n"
        f"cd -- {shlex.quote(str(ROOT))}\n"
        "clear\n"
        f"printf '%s\\n' {shlex.quote('WiFiAudit — ' + title)}\n"
        "printf '%s\\n\\n' 'La password sudo, se richiesta, viene letta esclusivamente dal terminale.'\n"
        f"printf '%s\\n' {shlex.quote('Comando previsto: ' + quoted)}\n"
        f"{worker}\n"
        "rc=$?\n"
        "printf '\\nOperazione terminata (codice %s). Premi Invio per chiudere.\\n' \"$rc\"\n"
        "read -r _ || true\n"
        "exit \"$rc\"\n"
    )
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(body)
    os.chmod(path, 0o700)
    JOB_IDS[str(path)] = ident
    return path


JOB_IDS: dict[str, str] = {}


def launch_terminal(argv: list[str], needs_sudo: bool, title: str) -> str:
    require_package()
    terminal = find_terminal()
    job = make_job(argv, needs_sudo, title)
    name = Path(terminal).name
    if name == "gnome-terminal":
        cmd = [terminal, "--", "bash", str(job)]
    elif name == "xfce4-terminal":
        cmd = [terminal, "--disable-server", "-e", f"bash {shlex.quote(str(job))}"]
    else:
        cmd = [terminal, "-e", "bash", str(job)]
    try:
        subprocess.Popen(cmd, cwd=ROOT, start_new_session=True, close_fds=True)
    except OSError:
        dashboard.update_job(JOB_IDS[str(job)], 'FALLITA', 127)
        raise
    return name


def launch_utility(payload: dict[str, Any]) -> str:
    utility = utility_from_payload(payload)
    command = str(utility["command"])
    executable = shutil.which(command)
    if not executable:
        package = utility.get("package")
        hint = f" Installa il pacchetto {package}." if package else " Consulta la guida ufficiale per installarla."
        raise LaunchError(f"{utility['label']} non è installato.{hint}")
    argv = [executable, *[str(item) for item in utility.get("args", [])]]
    if utility["gui"]:
        ident = dashboard.new_job(str(utility['label']), argv)
        try:
            subprocess.Popen([sys.executable, str(ROOT / 'dashboard.py'), 'run', ident], cwd=ROOT, start_new_session=True, close_fds=True)
        except OSError:
            dashboard.update_job(ident, 'FALLITA', 127)
            raise
    else:
        launch_terminal(argv, False, str(utility["label"]))
    return f"{utility['label']} avviato"


def open_local(path: Path) -> None:
    if not path.exists():
        raise LaunchError(f"Non trovato: {path.name}")
    opener = shutil.which("xdg-open")
    if not opener:
        raise LaunchError("xdg-open non è disponibile")
    subprocess.Popen([opener, str(path)], cwd=ROOT, start_new_session=True, close_fds=True)


def installed_packages() -> set[str]:
    query = shutil.which("dpkg-query")
    if not query:
        return set()
    try:
        result = subprocess.run(
            [query, "-W", "-f=${binary:Package}\t${db:Status-Abbrev}\n", *sorted(ALLOWED_PACKAGES)],
            capture_output=True, text=True, timeout=8, check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return set()
    installed: set[str] = set()
    for line in result.stdout.splitlines():
        fields = line.split("\t", 1)
        if len(fields) == 2 and fields[1].startswith("ii"):
            installed.add(fields[0].split(":", 1)[0])
    return installed


def status_payload() -> dict[str, Any]:
    tools = ["python3", "aircrack-ng", "hcxdumptool", "hcxpcapngtool", "hashcat", "john", "wifite", "reaver"]
    installed = installed_packages()
    return {
        "version": APP_VERSION,
        "package": all(p.is_file() for p in (CORE, ROOT / "wifiaudit_v6.sh", ROOT / "wifiaudit_tools.py")),
        "manual": MANUAL.is_file(),
        "terminal": next((name for name in TERMINALS if command_exists(name)), None),
        "results": str(RESULTS),
        "tools": {name: command_exists(name) for name in tools},
        "utilities": {key: {"label": value["label"], "installed": command_exists(str(value["command"])), "installable": bool(value.get("package")), "package": value.get("package")} for key, value in UTILITIES.items()},
        "package_groups": {
            key: {
                "label": group["label"],
                "description": group["description"],
                "packages": [
                    {"name": name, "description": description, "installed": name in installed}
                    for name, description in group["packages"].items()
                ],
            }
            for key, group in PACKAGE_GROUPS.items()
        },
        "running_as_root": os.geteuid() == 0,
    }


class AppServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False

    def __init__(self, address: tuple[str, int], token: str):
        super().__init__(address, Handler)
        self.token = token


class Handler(BaseHTTPRequestHandler):
    server_version = "WiFiAuditLauncher"

    @property
    def app(self) -> AppServer:
        return self.server  # type: ignore[return-value]

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stderr.write("[launcher] " + (fmt % args) + "\n")

    def common_headers(self, content_type: str) -> None:
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")

    def send_bytes(self, data: bytes, content_type: str, status: int = 200) -> None:
        self.send_response(status)
        self.common_headers(content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, value: dict[str, Any], status: int = 200) -> None:
        self.send_bytes(json.dumps(value, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8", status)

    def do_GET(self) -> None:
        if not self.valid_host():
            self.send_json({'ok': False, 'error': 'Host non consentito'}, 403)
            return
        path = self.path.split("?", 1)[0]
        if path == "/":
            template = (ROOT / "index.html").read_text(encoding="utf-8")
            page = template.replace("__TOKEN__", self.app.token).replace("__VERSION__", APP_VERSION)
            self.send_bytes(page.encode("utf-8"), "text/html; charset=utf-8")
            return
        if path == "/api/status":
            if not self.valid_request():
                self.send_json({'ok': False, 'error': 'Richiesta non autorizzata'}, 403)
                return
            self.send_json(status_payload())
            return
        if path == '/api/dashboard':
            if not self.valid_request():
                self.send_json({'ok': False, 'error': 'Richiesta non autorizzata'}, 403)
                return
            try:
                self.send_json({'ok': True, 'jobs': dashboard.jobs(), 'snapshots': dashboard.snapshots()})
            except (ValueError, OSError) as exc:
                self.send_json({'ok': False, 'error': str(exc)}, 400)
            return
        static = STATIC_FILES.get(path)
        if static and static[0].is_file():
            self.send_bytes(static[0].read_bytes(), static[1])
            return
        self.send_json({"ok": False, "error": "Risorsa non trovata"}, HTTPStatus.NOT_FOUND)

    def valid_host(self) -> bool:
        return self.headers.get('Host') == f'127.0.0.1:{self.app.server_port}'

    def valid_request(self) -> bool:
        if not self.valid_host():
            return False
        if self.headers.get("X-WiFiAudit-Token") != self.app.token:
            return False
        origin = self.headers.get("Origin")
        expected = f"http://127.0.0.1:{self.app.server_port}"
        return origin in (None, expected)

    def do_POST(self) -> None:
        if self.path != "/api/action" or not self.valid_request():
            self.send_json({"ok": False, "error": "Richiesta non autorizzata"}, HTTPStatus.FORBIDDEN)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 1 <= length <= 8192:
                raise LaunchError("Richiesta non valida")
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(payload, dict):
                raise LaunchError("Richiesta non valida")
            action = payload.get("action")
            if payload.get('dry_run') is True and action in {'menu', 'guided', 'doctor', 'selftest', 'catalog', 'inspect', 'recover', 'resume', 'install_utility', 'install_packages', 'apt_update', 'open_utility', 'netpwn_install', 'netpwn_demo', 'netpwn_stop'}:
                if action == 'open_utility':
                    tool = utility_from_payload(payload)
                    argv, sudo, title = [tool['command'], *tool.get('args', [])], False, tool['label']
                else:
                    argv, sudo, title = build_action(payload)
                command = (['sudo', '-k', '--'] if sudo else []) + argv
                ident = dashboard.new_job(title, command, simulated=True)
                self.send_json({'ok': True, 'message': 'SIMULAZIONE: nessun comando eseguito', 'job_id': ident, 'command': command})
                return
            if action == 'import_scan':
                data = dashboard.import_scan(str(payload.get('path', '')))
                self.send_json({'ok': True, 'message': 'Scansione importata', **data})
                return
            if action == 'sessions':
                self.send_json({'ok': True, 'sessions': dashboard.session_catalog(str(payload.get('path') or RESULTS))})
                return
            if action == 'hardware':
                self.send_json({'ok': True, **dashboard.hardware_status()})
                return
            if action == 'diff':
                self.send_json({'ok': True, 'diff': dashboard.diff(payload.get('before'), payload.get('after'))})
                return
            if action == 'kismet_import':
                self.send_json({'ok': True, 'message': 'Inventario Kismet importato', **dashboard.kismet_import(payload.get('key'), payload.get('port', 2501))})
                return
            if action == 'pdf_report':
                path = Path(dashboard.report_pdf(payload.get('id')))
                self.send_bytes(path.read_bytes(), 'application/pdf')
                return
            if action == "manual":
                open_local(MANUAL)
                result = "Manuale aperto"
            elif action == "results":
                RESULTS.mkdir(mode=0o700, parents=True, exist_ok=True)
                os.chmod(RESULTS, 0o700)
                open_local(RESULTS)
                result = "Cartella risultati aperta"
            elif action == "open_utility":
                result = launch_utility(payload)
            elif action == "shutdown":
                result = "Pannello arrestato"
                threading.Thread(target=self.app.shutdown, daemon=True).start()
            else:
                argv, sudo, title = build_action(payload)
                terminal = launch_terminal(argv, sudo, title)
                result = f"{title} avviato in {terminal}"
            self.send_json({"ok": True, "message": result})
        except (LaunchError, ValueError, OSError, TypeError) as exc:
            self.send_json({"ok": False, "error": str(exc)}, HTTPStatus.BAD_REQUEST)


def install_desktop() -> int:
    target_dir = Path.home() / ".local" / "share" / "applications"
    target_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    target = target_dir / "wifiaudit-launcher.desktop"
    launcher = ROOT / "avvia_pannello.sh"
    desktop_exec = str(launcher).replace("\\", "\\\\").replace('"', '\\"').replace("$", "\\$").replace("`", "\\`")
    content = "\n".join((
        "[Desktop Entry]", "Type=Application", "Name=WiFiAudit",
        "Comment=Pannello locale per WiFiAudit", f'Exec="{desktop_exec}"',
        "Icon=network-wireless", "Terminal=false", "Categories=System;Network;Security;",
        "StartupNotify=true", "",
    ))
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write(content)
    os.chmod(target, 0o600)
    print(f"Collegamento creato: {target}")
    return 0


def choose_server(token: str) -> AppServer:
    try:
        return AppServer(("127.0.0.1", 8765), token)
    except OSError:
        return AppServer(("127.0.0.1", 0), token)


def main() -> int:
    os.umask(0o077)
    parser = argparse.ArgumentParser(description="Pannello locale WiFiAudit")
    parser.add_argument("--check", action="store_true", help="controlla il pacchetto senza avviare il server")
    parser.add_argument("--no-browser", action="store_true", help="non aprire automaticamente il browser")
    parser.add_argument("--install-desktop", action="store_true", help="crea il collegamento nel menu applicazioni")
    args = parser.parse_args()
    if args.install_desktop:
        return install_desktop()
    try:
        require_package()
    except LaunchError as exc:
        print(f"ERRORE: {exc}", file=sys.stderr)
        return 2
    if args.check:
        print(json.dumps(status_payload(), ensure_ascii=False, indent=2))
        return 0
    if os.geteuid() == 0:
        print("Avvia il pannello come utente normale, senza sudo. Sudo verrà richiesto nel terminale.", file=sys.stderr)
        return 2
    token = secrets.token_hex(32)
    server = choose_server(token)
    url = f"http://127.0.0.1:{server.server_port}/"
    print(f"WiFiAudit Launcher {APP_VERSION}: {url}")
    print("Il server è accessibile solo da questo computer. Ctrl+C per chiudere.")
    if not args.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
