#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  printf '%s\n' 'Avvia questo pannello senza sudo. La password sarà richiesta nel terminale solo quando serve.' >&2
  exit 2
fi

command -v python3 >/dev/null 2>&1 || {
  printf '%s\n' 'Python 3 non è installato. Su Kali: sudo apt install python3' >&2
  exit 2
}

if [[ ${1:-} == --install ]]; then
  exec python3 "$SCRIPT_DIR/launcher.py" --install-desktop
fi

exec python3 "$SCRIPT_DIR/launcher.py" "$@"
