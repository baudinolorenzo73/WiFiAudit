"""Regenerate the manual with reportlab; not needed to run WiFiAudit."""
from pathlib import Path
import html
import os
import subprocess
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer, PageBreak, Preformatted

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'Manuale_wifiaudit_v6.0_Kali.pdf'
for name, filename in [('DV', 'DejaVuSans.ttf'), ('DVB', 'DejaVuSans-Bold.ttf'), ('DVM', 'DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name, '/usr/share/fonts/truetype/dejavu/' + filename))
pdfmetrics.registerFontFamily('DV', normal='DV', bold='DVB', italic='DV', boldItalic='DVB')
navy, teal, light = map(colors.HexColor, ['#153047', '#087F8C', '#EEF5F7'])
styles = {
    'title': ParagraphStyle('title', fontName='DVB', fontSize=23, leading=29, textColor=navy, spaceAfter=15),
    'body': ParagraphStyle('body', fontName='DV', fontSize=10, leading=15, textColor=navy, spaceAfter=9),
    'sub': ParagraphStyle('sub', fontName='DVB', fontSize=12, leading=16, textColor=teal, spaceBefore=12, spaceAfter=6),
    'cell': ParagraphStyle('cell', fontName='DV', fontSize=8.5, leading=12, textColor=navy),
    'code': ParagraphStyle('code', fontName='DVM', fontSize=8.3, leading=12, backColor=light, borderPadding=9, spaceAfter=12),
}
story = []
def p(text, style='body'):
    return Paragraph(text, styles[style])
def text(value):
    story.append(p(value))
def sub(value):
    story.append(p(value, 'sub'))
def code(value):
    story.append(Preformatted(value, styles['code']))
def page(title):
    if story:
        story.append(PageBreak())
    story.append(p(title, 'title'))
def table(headings, rows, widths):
    data = [[p('<b>' + html.escape(str(x)) + '</b>', 'cell') for x in headings]]
    data += [[p(html.escape(str(x)), 'cell') for x in row] for row in rows]
    t = Table(data, colWidths=widths, repeatRows=1, hAlign='LEFT')
    t.setStyle(TableStyle([('VALIGN', (0,0), (-1,-1), 'TOP'), ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#D2E6EB')),
                          ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, light]),
                          ('LEFTPADDING', (0,0), (-1,-1), 7), ('RIGHTPADDING', (0,0), (-1,-1), 7),
                          ('TOPPADDING', (0,0), (-1,-1), 7), ('BOTTOMPADDING', (0,0), (-1,-1), 7)]))
    story.extend([t, Spacer(1, 8)])

page('WiFiAudit 6.0\nManuale Kali Linux'.replace('\n', '<br/>'))
text('Guida operativa per Lorenzo - 10 novembre 2026. Motore WiFiAudit 6.0 con pannello Cyberpunk 1.6, procedura Wifite mirata, recupero offline, storico, report e backup.')
sub('Preparazione')
text('Estrai tutto il pacchetto ZIP in una cartella. I tre file wifiaudit.sh, wifiaudit_v6.sh e wifiaudit_tools.py devono rimanere insieme. La versione 6 aggiunge un helper Python e non è più un singolo file autosufficiente.')
code('bash wifiaudit.sh --menu\nbash wifiaudit.sh --self-test\nbash wifiaudit.sh --doctor')
text('Per la procedura radio sulla tua rete o su una rete autorizzata, apri lo stesso menu con root:')
code('sudo bash wifiaudit.sh --menu')
text('Root è necessario per le interfacce radio. Diagnostica, analisi dei file, catalogo, backup e recupero offline possono funzionare come utente normale, con file e cartelle accessibili. Con sudo HOME può diventare /root: configurazione e risultati predefiniti cambiano di conseguenza.')
sub('Leggere il PDF su Kali')
text('Apri questo file dal gestore file oppure usa l’applicazione associata:')
code('xdg-open Manuale_wifiaudit_v6.0_Kali.pdf')
text('Se manca un lettore puoi installare esplicitamente Evince con sudo apt install evince. Lo script non installa pacchetti per conto tuo.')
sub('Limiti del risultato')
text('Non esiste una garanzia di recuperare una password robusta. I test di questa consegna usano file sintetici e motori simulati: radio, GPU, conversioni reali e comportamento della versione di Kali richiedono un laboratorio. I file dei risultati contengono dati sensibili; i permessi privati non sono cifratura.')

page('Pannello Cyberpunk 1.6')
text('Il pannello locale organizza avvii, installazioni, storico delle osservazioni, confronto tra scansioni e rapporti PDF. Avvialo come utente normale: quando una funzione richiede privilegi, Kali chiede la password sudo nel terminale. Il pannello non riceve e non conserva tale password.')
code('chmod +x avvia_pannello.sh\n./avvia_pannello.sh')
table(['Area', 'Funzione'], [
    ('Mission Control', 'Registra stato e durata degli avvii fatti dal pannello. COMPLETATA indica il codice di uscita del processo, non il recupero certo di una chiave.'),
    ('Simulazione', 'Mostra il comando principale senza eseguirlo. Non simula i singoli comandi interni del motore Bash o di Wifite.'),
    ('Storico', 'Importa CSV di airodump-ng, conserva digest e confronta le osservazioni per BSSID. Non osservato non significa necessariamente rimosso.'),
    ('PDF', 'Genera un rapporto delle osservazioni importate, senza password. Richiede python3-reportlab; un esempio sintetico è incluso.'),
    ('Kismet readonly', 'Legge lo stato e gli AP già raccolti da Kismet su 127.0.0.1 usando una chiave API temporanea con ruolo readonly. Non avvia acquisizioni.'),
    ('Hardware', 'Mostra interfacce e supporto monitor dichiarato dal driver. Non prova injection o stabilità radio.'),
    ('GitHub Pages', 'Offre guida, link e download. Una pagina web pubblicata non può avviare Bash, sudo o la radio del computer.')
], [125, 374])
text('Il registro privato è in $HOME/.local/state/wifiaudit-dashboard. Le sessioni lanciate con sudo possono finire in /root/wifiaudit_results e non sono leggibili dal pannello normale: non vengono indeboliti i permessi per aggirare questa separazione.')

page('Mappa degli strumenti Wi-Fi')
table(['Strumento', 'Ruolo nel pacchetto'], [
    ('Aircrack-ng', 'Monitor mode, scansione, catture, injection mirata e verifica offline nei flussi implementati.'),
    ('Kismet', 'Osservazione passiva, inventario e WIDS; integrazione API soltanto readonly.'),
    ('Wireshark / TShark / tcpdump', 'Analisi grafica o testuale delle catture. Non trovano automaticamente una password.'),
    ('Hashcat / John', 'Recupero offline con wordlist, regole e maschere; l’esito dipende da formato, hardware e qualità dei candidati.'),
    ('hcxdumptool / hcxtools', 'Acquisizione e conversione PMKID/EAPOL. Il motore filtra gli hash sul BSSID scelto quando possibile.'),
    ('Reaver / Pixiewps', 'Valutazione WPS. Pixiewps elabora offline i parametri raccolti; non rende vulnerabile un WPS bloccato.'),
    ('Wifite', 'Orchestratore esterno richiamato dalla procedura mirata con target, profilo e limite di tempo espliciti.'),
    ('Nmap / Hydra', 'Verifiche separate su host, porte e servizi già compresi nello scope. Hydra non recupera la chiave Wi-Fi.'),
    ('Airgeddon / Bettercap / Fern', 'Installabili come strumenti di laboratorio; il pannello non prepara campagne MITM o target.'),
    ('MDK4 / Wifiphisher / WiFiPumpkin3', 'Installabili, ma non avviabili automaticamente dal pannello per evitare flood, phishing o rogue AP non circoscritti.'),
    ('Pyrit', 'Non incluso: Kali lo ha rimosso nel 2020 perché basato su Python 2.')
], [150, 349])
text('Rogue AP, MITM, phishing, deauth e flood possono interrompere servizi o raccogliere dati. Richiedono un laboratorio isolato o uno scope scritto specifico; una generica autorizzazione alla scansione non basta.')
sub('Risorse web incluse nel pannello')
for label, url in [
    ('CyberChef', 'https://gchq.github.io/CyberChef/'),
    ('GTFOBins', 'https://gtfobins.org/'),
    ('explainshell', 'https://explainshell.com/'),
    ('HackTricks', 'https://book.hacktricks.wiki/'),
    ('OWASP Cheat Sheet Series', 'https://cheatsheetseries.owasp.org/')
]:
    text('<b>' + label + ':</b> <link href="' + url + '" color="#087F8C">' + url + '</link>')
text('Questi collegamenti aprono servizi esterni. Il pannello non invia automaticamente catture, log, password o file.')

page('Procedura guidata: rete e acquisizione')
text('Nel menu iniziale scegli <b>9</b>, oppure usa <b>--guided</b>. Questa procedura si avvia prima della suite tradizionale: se la suite ha già preparato il monitor, esci e riapri il menu iniziale per evitare due programmi sulla stessa scheda.')
table(['Passo', 'Comportamento'], [
    ('Target', 'Inserisci un solo BSSID, cioè il MAC dell’AP autorizzato. Canale e nome rete sono facoltativi. Il filtro BSSID è obbligatorio.'),
    ('Interfaccia', 'Inserisci il nome fisico della scheda, per esempio wlan1. Il programma non lo sceglie automaticamente nella procedura guidata.'),
    ('Profilo 1: osservazione', 'Passa a Wifite --nodeauths, --no-wps e --no-pmkid. Attende il traffico utile e le riconnessioni naturali. Il comportamento effettivo resta quello del Wifite installato.'),
    ('Profilo 2: audit attivo', 'Consente le tecniche WPA/WPS del programma esterno. Può interrompere connessioni. Non aggiunge captive portal o upload di catture.'),
    ('Limite', 'Fase Wifite: 900 secondi predefiniti, modificabili prima dell’avvio. Lo script controlla l’help locale e rifiuta versioni prive delle opzioni necessarie.'),
    ('Anteprima', 'Il comando e il target vengono mostrati. Soltanto una risposta s avvia la prova. Non vengono passati argomenti liberi o selezioni di tutte le reti.')
], [125, 374])
text('Wifite opera nella nuova cartella di sessione. I risultati relativi sono isolati da quelli di precedenti prove. Non viene usato --kill e non viene configurato alcun servizio esterno di recupero.')
sub('Dopo Wifite')
text('Se cracked.json contiene una chiave per il BSSID scelto, viene importata nel TSV e nel report. La chiave è dichiarata dal motore esterno: non viene eseguita una nuova connessione per verificarla. Lo stato di uscita 0 da solo non implica successo.')
text('Se è disponibile una cattura, viene tentata la conversione e vengono selezionati soltanto gli hash del BSSID scelto. Se la conversione non è disponibile o il target non ha hash utilizzabili, la cattura resta da verificare. Il recupero offline usa il budget AUTO_SECONDS separato. offline_link.txt collega le due sessioni: i due limiti non sono un unico timer globale.')

# Read descriptions from the implemented panel so defaults and documentation agree.
command = 'source "$1"; for key in "${SETTING_KEYS[@]}"; do printf "%s\\t%s\\t%s\\n" "$key" "${!key}" "$(setting_description "$key")"; done'
r = subprocess.run(['bash', '-c', command, 'manual', str(ROOT / 'wifiaudit.sh')], capture_output=True, text=True, check=True)
settings = []
for line in r.stdout.splitlines():
    name, value, description = line.split('\t', 2)
    if value.startswith(str(Path.home())):
        value = '$HOME' + value[len(str(Path.home())):]
    settings.append((name, value or '(vuoto)', description))
for n in range(3):
    page('Parametri con spiegazione - ' + str(n + 1))
    text('Dal menu iniziale scegli 3; nella suite usa p. Seleziona un numero per spiegazione e modifica. Invio conserva il valore, - lo svuota se consentito. Le impostazioni non valide vengono rifiutate.')
    table(['Parametro', 'Default', 'Significato'], settings[n*9:(n+1)*9], [120, 125, 254])
    if n == 2:
        text('s salva le impostazioni generali, l carica la configurazione, 0 torna indietro. Target, opzioni batch e AUTO_INPUT restano temporanei. La cartella risultati e l’interfaccia non sono modificabili durante una sessione operativa.')
        text('Config predefinita: $HOME/.config/wifiaudit/wifiaudit.conf. Sono ammesse soltanto assegnazioni di dati; il file non è eseguito come Bash. Il percorso completo deve avere proprietari fidati e non essere scrivibile da gruppo o altri utenti.')

page('Recupero offline e ripresa per fasi')
text('Menu iniziale 8, oppure suite 14. Il recupero lavora su catture e hash già presenti e usa soltanto motori compatibili. Supporta .22000 e .hccapx per hashcat, .john WPA per John e conversioni di .cap/.pcapng quando i convertitori sono disponibili.')
code('bash wifiaudit.sh --auto-recover /percorso/file.22000 \\\n  --auto-seconds 600')
text('Prova wordlist, regole disponibili e maschera configurata. Il budget predefinito è 600 secondi, con 120 secondi per tentativo. Conversioni, arresto dei processi e lettura dei risultati possono introdurre alcuni secondi aggiuntivi. Si ferma al primo risultato importabile, non necessariamente a tutte le chiavi di un file con più reti.')
sub('Riprendere')
code('bash wifiaudit.sh --resume /percorso/session_...')
text('Il checkpoint contiene dati e impronte SHA-256 di input e wordlist, insieme alle impostazioni dei tentativi. La ripresa rifiuta file o impostazioni cambiati, copia i potfile e salta le fasi completate. Una fase interrotta riparte dall’inizio: non viene ripresa la posizione esatta della ricerca. Dopo aggiornamenti dei motori o delle loro regole, preferisci una nuova sessione.')
text('La ripresa crea una nuova cartella; la vecchia non viene sovrascritta. Un lock impedisce due riprese contemporanee della stessa sessione. Input originale e checkpoint devono essere disponibili e appartenere a percorsi fidati.')
table(['Esito', 'Interpretazione'], [
    ('TROVATA', 'Almeno un valore importabile dal motore; leggere il file dei risultati.'),
    ('NON_TROVATA', 'Nessun risultato con le strategie effettivamente provate.'),
    ('TEMPO_ESAURITO / LIMITI_TEMPO_RAGGIUNTI', 'È stato raggiunto un limite globale o di uno o più tentativi.'),
    ('OUTPUT_DA_VERIFICARE', 'Output ambiguo, conservato senza indovinare il valore.'),
    ('FASI_GIA_COMPLETATE', 'Le fasi eseguibili erano già state completate nel checkpoint.'),
    ('ERRORE / NESSUN_TENTATIVO_ESEGUIBILE', 'Controllare file, strumenti, wordlist e log; non è una prova della robustezza della password.')
], [195, 304])

page('Catalogo, verifica file e backup')
text('Menu iniziale 10 o suite 15. Le funzioni lavorano sui file locali e non richiedono una scansione radio.')
code('bash wifiaudit.sh --catalog /percorso/wifiaudit_results\nbash wifiaudit.sh --inspect /percorso/cattura.cap')
text('Il catalogo elenca le cartelle session_* con numero di file e disponibilità di checkpoint. La verifica identifica gli header PCAP/PCAPNG e la sintassi di base dei file 22000. Se TShark è disponibile, conta i frame EAPOL con un timeout di 20 secondi.')
text('<b>Header, dimensione ed EAPOL presenti non dimostrano un handshake completo o una password recuperabile.</b> I file .john sono dichiarati dal formato e non validati completamente. Per analisi approfondita apri la cattura in Wireshark.')
sub('Backup della singola sessione')
code('bash wifiaudit.sh --backup-session \\\n  /percorso/session_... /percorso/backup.zip')
text('Seleziona una singola cartella session_*. Il file ZIP deve essere fuori dalla cartella di origine e non deve esistere già. Il programma non segue link simbolici e controlla proprietari e permessi del percorso. Il manifest contiene percorso, dimensione e SHA-256 dei dati effettivamente scritti nel backup.')
text('Il backup ha permessi 600, ma non è cifrato: può contenere catture, password, identità, log e potfile. Per una copia coerente di tutti i file, esegui il backup dopo aver chiuso la sessione.')
sub('Strumenti esterni opzionali')
text('Nel gestore sessioni puoi aprire Sniffnet, Wireshark o wavemon se già installati. Le applicazioni grafiche vengono suggerite in una sessione utente normale quando lo script gira come root. Nessuna di queste voci garantisce il recupero di una password.')

page('Suite tradizionale e risultati')
text('Il menu iniziale 1 conserva la suite precedente: prepara la scheda monitor dopo il controllo delle dipendenze. Non scegliere questa strada prima della procedura Wifite, perché quest’ultima gestisce autonomamente la propria interfaccia.')
table(['Voce', 'Funzione'], [
    ('1 / 2', 'Scansione e scelta target / diagnosi locale della cifratura. Lo stato WPS non è accertato dal solo CSV.'),
    ('3 / 4 / 5 / 6', 'Percorsi preesistenti: handshake, PMKID, WPS, WEP. Effetti e compatibilità dipendono dagli strumenti.'),
    ('7 / 8', 'AP di laboratorio con seconda scheda / raccolta EAP. Un’identità EAP non è una password.'),
    ('9 / 10 / 11', 'File manuale / maschere / wordlist derivata dal nome rete.'),
    ('12 / 13', 'Report HTML della sessione / cambio MAC opzionale con tentativo di ripristino.'),
    ('14 / 15', 'Recupero offline automatico / sessioni, verifica, ripresa e backup.'),
    ('p / d / t / h / ?', 'Parametri / diagnostica / self-test / aiuto CLI / spiegazioni generali.'),
    ('0', 'Uscita con tentativo di ripristino dei processi e delle modifiche gestite dalla suite.')
], [115, 384])
sub('Dove leggere il risultato')
text('Radice predefinita: $HOME/wifiaudit_results. Ogni avvio crea una cartella session_*. Il TSV della radice è cumulativo; quello della sessione comprende soltanto i risultati della prova corrente. I report HTML non importano l’intero archivio storico.')
text('TSV: timestamp, BSSID, ESSID, fonte, engine, valore, tipo. TAB, ritorni a capo e backslash sono rappresentati con escape per non spezzare le righe. PIN WPS, chiavi WEP e identità EAP restano tipi distinti. I log dei programmi esterni possono contenere dati sensibili.')
text('Il risk score preesistente è aggregato: aperte × 10 + WEP × 8 + WPA × 5. Fasce: 0 BASSO, 1-20 MODERATO, 21-50 ALTO, oltre 50 CRITICO. Non misura la sicurezza di una password specifica; senza scansione resta NON_VALUTATO.')

page('Installazione e problemi comuni')
text('Bash e Python 3.11+ sono necessari per il pacchetto completo. La parte Python usa solo la libreria standard. Per operazioni radio serve una scheda compatibile; in una VM Kali il dispositivo USB deve essere esposto alla VM.')
code('sudo apt update\nsudo apt install wifite aircrack-ng hcxdumptool hcxtools \\\n  hashcat john reaver pixiewps crunch hostapd dnsmasq iptables \\\n  tshark tcpdump macchanger iw iproute2 util-linux coreutils python3')
text('Questo comando è una scelta esplicita dell’operatore: WiFiAudit non lo esegue automaticamente. L’esistenza del pacchetto non garantisce supporto a tutte le opzioni del ramo GitHub più recente. Esegui --doctor e leggi l’help locale.')
table(['Problema', 'Che cosa verificare'], [
    ('Manca un modulo', 'Estrarre tutto lo ZIP; mantenere i tre file di programma nella stessa cartella.'),
    ('Config o sessione non fidata', 'Proprietario e permessi di file e directory superiori. Non usare chmod 777. Root e utente normale hanno percorsi distinti.'),
    ('Wifite incompatibile', 'La procedura si ferma se mancano filtro BSSID o opzioni del profilo. Controllare l’help e la versione locale.'),
    ('Nessuna cattura o chiave', 'Verificare segnale, scheda, client, configurazione AP e log. Il timeout non indica che la password sia sicura o impossibile da recuperare.'),
    ('Ripresa rifiutata', 'Input o wordlist cambiati, impostazioni diverse, checkpoint assente o altra ripresa in corso. Avviare una nuova sessione se necessario.'),
    ('Interfaccia dopo un crash', 'La suite tenta il proprio cleanup; Wifite gestisce il suo. SIGKILL, spegnimenti e driver possono impedire il ripristino: verificare manualmente senza cancellare regole di altri servizi.')
], [142, 357])

page('Verifiche e riferimenti')
text('Verificato qui: sintassi dei due file Bash, 8 controlli interni e suite di test locale. I test coprono filtri di target, importazione per BSSID, conferma, errori di compatibilità, checkpoint e input modificati, symlink, permessi e backup. I motori radio e di recupero nei test sono simulati.')
code('python3 tests/test_v6.py\nbash -n wifiaudit.sh\nbash -n wifiaudit_v6.sh\nbash wifiaudit.sh --self-test')
text('Da collaudare sul tuo Kali: Wifite reale, formati di output effettivi, John/hashcat e convertitori, prestazioni GPU, comportamento dei driver e ripristino delle interfacce. Il pacchetto non certifica capacità generiche di attacco WPA3 e non introduce una garanzia di trovare password sconosciute.')
sub('File della procedura guidata')
text('guided_scope.txt documenta il target; wifite.log contiene l’output; guided_risultato.txt riassume lo stato. Se esiste una fase offline, offline_link.txt ne indica cartella ed esito. checkpoint.json e completed.txt servono alla ripresa; non devono essere eseguiti né modificati a mano.')
sub('Riferimenti ufficiali consultati')
for url in ['https://www.kali.org/tools/wifite/', 'https://github.com/kimocoder/wifite2',
            'https://github.com/ZerBea/hcxtools', 'https://github.com/hashcat/hashcat',
            'https://github.com/openwall/john', 'https://github.com/GyulyVGC/sniffnet',
            'https://www.kali.org/tools/tcpdump/', 'https://www.kali.org/tools/pixiewps/',
            'https://www.kali.org/tools/bettercap/', 'https://www.kali.org/tools/mdk4/']:
    text('<link href="' + url + '" color="#087F8C">' + url + '</link>')
text('L’integrazione richiama programmi esterni: non incorpora il loro codice. La documentazione del pacchetto distingue le funzioni implementate dalle capacità dichiarate dai singoli progetti. Il vecchio genera_manuale.sh non è stato utilizzato.')

def decorate(c, doc):
    c.saveState()
    c.setStrokeColor(teal); c.line(48, A4[1]-35, A4[0]-48, A4[1]-35)
    c.setFont('DV', 8); c.setFillColor(navy)
    c.drawString(48, A4[1]-26, 'WIFIAUDIT 6.0 / CONTROL DECK 1.6 / 10.11.2026')
    c.line(48, 38, A4[0]-48, 38)
    c.drawString(48, 24, 'Manuale operativo - collaudo hardware ancora necessario')
    c.drawRightString(A4[0]-48, 24, str(doc.page))
    c.restoreState()

SimpleDocTemplate(str(OUT), pagesize=A4, leftMargin=48, rightMargin=48, topMargin=55, bottomMargin=52,
                  title='WiFiAudit 6.0 - Manuale Kali e pannello 1.6', author='Guida per Lorenzo').build(story, onFirstPage=decorate, onLaterPages=decorate)
print(OUT)
