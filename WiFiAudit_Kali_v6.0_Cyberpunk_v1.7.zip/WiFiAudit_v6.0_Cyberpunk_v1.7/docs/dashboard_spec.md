# Dashboard 1.6 - Specifica, piano e verifica

## Obiettivo e requisiti

Trasformare il pannello in un'interfaccia con stato delle attività, storico delle osservazioni, confronto e report PDF. Preservare le funzioni del motore 6.0, i pacchetti predefiniti, il tema cyberpunk e la pubblicazione statica.

1. Un esecutore unico registra gli avvii del pannello, con titolo, comando, data, heartbeat e codice di uscita. Password e output del terminale non vengono catturati.
2. Una simulazione esplicita visualizza il comando principale senza eseguirlo. Non simula i singoli comandi interni di Bash/Wifite.
3. Gli snapshot importano CSV AP airodump-ng, mantengono origine e digest e consentono confronti per BSSID. I client non sono importati. Non osservato non significa rimosso.
4. La lista sessioni legge solo cartelle accessibili all'utente e stati noti dal campo Esito.
5. I PDF descrivono le scansioni importate e i limiti delle osservazioni. Non includono password né dichiarazioni di cracking riuscito. Massimo 2000 righe nel rapporto.
6. Kismet: solo loopback, API key temporanea con ruolo readonly, timeout, limite 4 MiB, nessun redirect o proxy. Si leggono stato e AP già raccolti. Nessuna acquisizione viene avviata dal connettore.
7. Hardware: interfacce e modalità monitor dichiarata dal driver, senza prova di injection.
8. Risorse: link esterni verificati; nessun caricamento automatico o invio di catture ai siti esterni.
9. Demo sintetica nel browser, senza database o hardware, distinguibile dai dati locali. GitHub Pages continua a offrire guida e download.
10. Catalogo esteso: strumenti correnti dei repository Kali separati tra componenti del motore, guide locali e laboratorio avanzato. Nessuna automazione di phishing, MITM, deauth massivo o flood. Pyrit e sorgenti esterne obsolete sono esclusi.

## Architettura

- `launcher.py`: API con allowlist, token, Host e Origin, terminali e installazioni.
- `dashboard.py`: SQLite privato, worker con IO ereditato dal terminale, parser CSV, diff, PDF e Kismet.
- `dashboard-ui.js`: aggiornamento attività mentre sono aperte, importazioni, demo e download PDF.
- `history.sqlite3`: `~/.local/state/wifiaudit-dashboard/`, directory 700 e file 600. Registro attività e snapshot, non password.
- `reports/`: PDF privati generati esplicitamente. Il download non elimina la copia locale.

Le sessioni avviate fuori dal pannello non appaiono nel registro attività. Quelle presenti su disco sono consultabili dal catalogo. Il motore eseguito con sudo può salvare in `/root/wifiaudit_results`: il pannello normale non può aggirare tali permessi. Scegliere una cartella leggibile o esportare una cattura attraverso il flusso autorizzato del motore.

## Stati

IN_ATTESA, IN_CORSO, COMPLETATA, FALLITA, INTERROTTA, SIMULATA, STATO_SCONOSCIUTO. COMPLETATA riguarda il processo, non prova che una chiave sia stata recuperata. In assenza di heartbeat per 45 secondi lo stato diventa sconosciuto: il programma non presume che il processo sia terminato e non lo riavvia automaticamente. L'interruzione normale si effettua con Ctrl+C nel terminale; SIGKILL, driver bloccati e riavvio del sistema possono richiedere controllo manuale.

## Kismet

Documentazione: https://www.kismetwireless.net/docs/api/login/ e https://www.kismetwireless.net/docs/api/device_views/ . Usa cookie `KISMET` e un'API key readonly già creata in Kismet. Percorsi fissati nel codice: GET `/system/status.json` e GET `/devices/views/phydot11_accesspoints/last-time/0/devices.json`. Il nome dispositivo è conservato come nome dichiarato, senza inferire un SSID verificato. Campi mancanti restano vuoti o NON_VERIFICATO. Testato con fixture API, non con un Kismet installato.

## Piano e attività

- [x] Esecutore centralizzato, worker e heartbeat
- [x] Simulazione degli avvii
- [x] Importazione CSV, storico e confronto
- [x] Catalogo sessioni accessibili
- [x] Rapporto PDF ed esempio sintetico verificato visivamente
- [x] API Kismet readonly e stato hardware
- [x] Link ufficiali e repository di riferimento
- [x] Catalogo Kali esteso, gruppo laboratorio e confini operativi
- [x] Fixture, regressioni e protezioni HTTP
- [ ] Collaudo sul desktop Kali e hardware reale
- [ ] Collaudo live Kismet, installabilità PWA e ciclo offline nel browser reale

## Ripristino

Installare questa versione in una cartella nuova. I vecchi risultati del motore e i pacchetti precedenti non vengono eliminati. Il registro SQLite resta separato dalle catture e dai report originali. Nessuna migrazione distruttiva.
