# Piano tecnico — Pannello HTML locale

1. Server Python standard-library legato a localhost.
2. HTML, CSS e JavaScript offline senza CDN o telemetria.
3. Ogni pulsante diventa un array di argomenti ammesso e viene aperto in un terminale.
4. Validazione di catture, sessioni, durata e identificativi delle utilità.
5. Token, controllo Origin, CSP, limite dimensione e nessuna shell libera.
6. Avviatore Bash e collegamento desktop facoltativo.
7. Guida comandi e utilità a due pannelli per facilitare l'uso su Kali.
8. Test di sintassi, unit test, server HTTP e contenuto ZIP.
9. Rendere il tema cyberpunk con soli CSS locali e una modalità a movimento ridotto.
10. Interrogare `dpkg-query` in sola lettura e mostrare pacchetti presenti/mancanti.
11. Generare i comandi APT da un catalogo server-side immutabile.
12. Usare asset relativi e una modalità statica che non interroghi API inesistenti su GitHub Pages.
13. Aggiungere manifest, icone, service worker versionato e ZIP Pubblica a radice piatta.
14. Aggiungere un gruppo Analisi e rete e launcher controllati per la toolchain richiesta.
15. Aprire Hydra e Nmap soltanto con l’help, senza target o parametri di attacco precompilati.

## Ripristino

I file del pannello sono aggiuntivi: rimuoverli non modifica i tre componenti del motore WiFiAudit v6.0.
