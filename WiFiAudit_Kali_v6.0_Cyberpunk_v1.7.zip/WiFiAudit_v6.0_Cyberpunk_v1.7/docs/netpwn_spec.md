# Integrazione NetPwn 1.7

Obiettivo: provare NetPwn su Kali dal pannello esistente mediante demo esterna opzionale.

Requisiti: revisione fissa; download esplicito; venv separato; nessun sudo; argomenti fissi --demo e loopback; nessun avvio reale; arresto limitato al processo proprio con verifica identità; compatibilità dry-run e GitHub Pages; nessuna migrazione dati.

Piano: aggiungere netpwn_bridge.py, tre azioni nell'allowlist, scheda HTML e guida. Conservare il pacchetto 1.6 come ripristino. Il sorgente upstream viene scaricato su Kali, non distribuito nel pacchetto.

Attività: implementazione bridge e UI; test di argomenti, mancata preparazione, processo riutilizzato, arresto, comportamento di esecuzione con fixture; regressione e validazione pacchetti.

Limiti: dipendenze transitive non bloccate; demo upstream non è una sandbox; nessun bus eventi/topologia incorporati nel backend WiFiAudit. Apertura nel browser e installazione reale da collaudare su Kali.
