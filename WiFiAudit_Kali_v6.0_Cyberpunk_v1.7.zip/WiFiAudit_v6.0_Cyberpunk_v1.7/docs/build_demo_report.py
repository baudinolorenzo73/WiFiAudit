#!/usr/bin/env python3
"""Build a clearly synthetic sample without touching the operator database."""
from pathlib import Path
import shutil
import sys
import tempfile
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import dashboard


if __name__ == '__main__':
    with tempfile.TemporaryDirectory(dir=Path.home()) as directory:
        with mock.patch.object(dashboard.Path, 'home', return_value=Path(directory)):
            networks = [
                {'bssid': '02:00:00:00:00:01', 'essid': 'Laboratorio DEMO <nessuna rete reale>', 'channel': '6', 'security': 'WPA2 CCMP', 'signal': '-45', 'auth': 'PSK', 'cipher': 'CCMP'},
                {'bssid': '02:00:00:00:00:03', 'essid': 'Ospiti DEMO', 'channel': '11', 'security': 'OPN', 'signal': '-70', 'auth': '', 'cipher': ''},
            ]
            ident = dashboard.save_snapshot('ESEMPIO DEMO - dati interamente sintetici', 'SINTETICO', networks, '0' * 64)
            report = dashboard.report_pdf(ident)
            shutil.copyfile(report, ROOT / 'Rapporto_esempio_DEMO.pdf')
    print(ROOT / 'Rapporto_esempio_DEMO.pdf')
