#!/usr/bin/env python3
"""Reproducible full Kali bundle and flat GitHub Pages bundle."""
from pathlib import Path
import hashlib
import subprocess
import sys
import tempfile
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = '1.7'


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('Uso: build_packages.py CARTELLA_OUTPUT VALIDATORE_PUBBLICA')
    output = Path(sys.argv[1]).resolve(); output.mkdir(parents=True, exist_ok=True)
    validator = Path(sys.argv[2]).resolve()
    files = sorted(p for p in ROOT.rglob('*') if p.is_file() and not p.is_symlink()
                   and not any(x in ('__pycache__', '.git', 'node_modules') for x in p.relative_to(ROOT).parts)
                   and p.suffix not in ('.pyc', '.sqlite3') and p.name not in ('SHA256SUMS', '.env'))
    manifest = ''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.relative_to(ROOT).as_posix() + '\n' for p in files)
    (ROOT / 'SHA256SUMS').write_text(manifest, encoding='utf-8')
    files.append(ROOT / 'SHA256SUMS')
    full = output / f'WiFiAudit_Kali_v6.0_Cyberpunk_v{VERSION}.zip'
    with zipfile.ZipFile(full, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for p in files:
            archive.write(p, f'WiFiAudit_v6.0_Cyberpunk_v{VERSION}/' + p.relative_to(ROOT).as_posix())
    public = output / f'WiFiAudit_Pubblica_GitHub_v{VERSION}.zip'
    with tempfile.TemporaryDirectory() as directory:
        stage = Path(directory)
        for name in ('index.html', 'app.css', 'app.js', 'dashboard-ui.js', 'manifest.webmanifest', 'sw.js',
                     'Manuale_wifiaudit_v6.0_Kali.pdf', 'Rapporto_esempio_DEMO.pdf', 'GUIDA_PANNELLO_KALI.md', 'GUIDA_NETPWN.md', '.nojekyll'):
            shutil.copyfile(ROOT / name, stage / name)
        shutil.copytree(ROOT / 'icons', stage / 'icons')
        shutil.copyfile(full, stage / full.name)
        subprocess.run([sys.executable, str(validator), str(stage), str(public), '--require-pwa'], check=True)
    for path in (full, public):
        with zipfile.ZipFile(path) as archive:
            if archive.testzip() is not None:
                raise ValueError('ZIP non valido')
        print(path, path.stat().st_size)
