# Specifica — Pannello HTML locale WiFiAudit

## Risultato atteso

Fornire su Kali Linux un pannello HTML per avviare le funzioni già presenti in WiFiAudit v6.0 senza digitare ogni comando. Il browser non può eseguire Bash direttamente: il pannello usa un server Python locale e apre le operazioni in un terminale separato.

## Requisiti

1. Avvio come utente normale; elevazione solo nel terminale per le funzioni che la richiedono.
2. Nessuna memorizzazione o trasmissione della password `sudo`.
3. Server vincolato a `127.0.0.1`, token casuale e comandi predefiniti, senza shell libera.
4. Pulsanti per menu, guidata, doctor, self-test, catalogo, manuale e risultati.
5. Ispezione e recupero offline da percorsi con formato ammesso; ripresa solo da cartelle `session_*`.
6. Avvio e installazione controllata di utilità note; nessun nome pacchetto fornito liberamente dal browser.
7. Guida integrata ai comandi principali, responsive e utilizzabile offline.
8. Conservazione integrale delle funzioni WiFiAudit v6.0.
9. Tema cyberpunk leggibile, responsive e rispettoso di `prefers-reduced-motion`.
10. Centro installazioni con stato dei pacchetti e gruppi Wi-Fi, archivi, PDF, DOCX, file manager e sistema.
11. Installazione esclusivamente da allowlist incorporata; nessun nome di pacchetto libero inviato dal browser.
12. Compatibilità GitHub Project Pages tramite percorsi relativi, anteprima statica e PWA offline.
13. Separazione esplicita: sito pubblico per guida/download; server locale per terminale, Bash e sudo.
14. Toolchain visibile e installabile: Aircrack-ng, Kismet, Hashcat, John, Wireshark, Nmap e Hydra.
15. Hydra e Nmap non devono essere automatizzati contro target: solo installazione, avvio informativo e uso manuale autorizzato.

## Confini

- Non sostituisce WiFiAudit e non implementa nuovi metodi radio.
- Non garantisce recupero di password.
- Sniffnet richiede installazione separata; il pannello non aggiunge repository esterni.
- Funziona solo mentre `launcher.py` è in esecuzione sul computer locale.

## Criteri di accettazione

- `python3 launcher.py --check` verifica il pacchetto senza rete o root.
- La pagina carica da localhost e mostra componenti e utilità.
- Le azioni privilegiate usano `sudo -k` nel terminale; il server resta non privilegiato.
- Azioni, percorsi, estensioni, pacchetti, dimensione richieste, origine e token sono validati.
- I test automatici non avviano strumenti radio né richiedono root.
- Il browser può richiedere `apt-get update` e l'installazione dei soli pacchetti autorizzati, sempre in terminale e dopo conferma.
- Sotto una sottocartella GitHub Pages CSS, JavaScript, manifest, icone e service worker devono risolversi senza riferimenti alla radice del dominio.
