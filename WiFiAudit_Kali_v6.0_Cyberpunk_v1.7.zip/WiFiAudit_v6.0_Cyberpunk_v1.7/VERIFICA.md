# Verifica WiFiAudit 6.0

## Pannello 1.7 - 11 novembre 2026

- Bridge NetPwn indipendente, revisione c409bda64590dcba1cef2ee66188607ab14c723a: download esplicito, venv e avvio demo senza sudo su loopback 8877.
- 8 test bridge: argomenti fissi, rifiuto root, preparazione incompleta preservata, revisione fissata, demo non preparata, flag e ambiente, protezione PID riutilizzato, avvio e arresto di un processo reale innocuo con fixture al posto di NetPwn.
- Regressione: 48 test Python preesistenti e smoke JavaScript superati; totale 56 test Python. Sintassi e validazione ZIP/PWA verificate.
- Il sorgente upstream è stato letto tramite GitHub. Il NetPwn reale, il download pip e il browser su Kali non sono stati eseguiti qui. Dipendenze transitive non bloccate e demo upstream non isolata da sandbox.
- Manuale PDF 1.6 conservato; GUIDA_NETPWN.md contiene i nuovi passaggi 1.7. Nessun codice upstream redistribuito.

## Dashboard 1.6 - 10 novembre 2026

- 9 test di integrazione e dati dashboard, 14 test launcher e 25 test motore: superati.
- Test JavaScript con DOM sintetico: 8 gruppi, 16 utilità, modalità pubblica, demo e confronto corretti. Non è una prova di resa CSS.
- Worker provato su processi innocui con successo/fallimento; simulazione verificata senza avvio. Nessuna prova radio, installazione APT o cracking reale.
- API protette con Host/Origin/token: richieste senza token o da origine estranea rifiutate.
- CSV e differenze testati con fixture; link, file troppo grandi e intestazioni errate rifiutati. Catalogo: nessuna esposizione del testo libero con chiavi.
- Kismet verificato con risposte simulate e documentazione API; la chiave non compare nel database. Collegamento reale da collaudare su Kali.
- Rapporto PDF sintetico generato, testo estratto, renderizzato e controllato visivamente; font DejaVu incorporati. I PDF runtime restano da provare sulla propria installazione ReportLab.
- Resa grafica completa, apertura terminali, PWA installabile e riapertura offline: non verificati con browser reale in questo ambiente.

## Pannello HTML locale

- 14 test automatici del launcher: superati.
- Sintassi Python, JavaScript e Bash: superata.
- HTTP locale: pagina e stato `200`; richiesta senza token `403`; azione non ammessa `400`.
- Header verificati: CSP, `X-Frame-Options: DENY`, `nosniff`, `no-store`.
- Azioni e pacchetti limitati a liste predefinite; percorsi e formati validati.
- Otto gruppi e 54 voci pacchetto predefinite; input malevolo per il nome pacchetto rifiutato con HTTP 400.
- Stato pacchetti interrogato in sola lettura tramite `dpkg-query`; nessuna installazione eseguita durante i test.
- Nessun test ha avviato strumenti radio, installato pacchetti o richiesto una password.
- Resa grafica e apertura dei terminali da provare sul desktop Kali reale.
- Percorsi Project Pages verificati servendo il progetto sotto `/Kali_html/`: HTML, CSS, JavaScript, manifest e icona restituiti correttamente.
- Validatore Pubblica eseguito con PWA obbligatoria: superato, ZIP con `index.html` direttamente alla radice.
- Modalità web statica verificata sul codice e sugli asset; installazione PWA e resa finale restano da confermare nel browser dopo la pubblicazione.
- Toolchain richiesta verificata nell’allowlist e nel launcher: Aircrack-ng, Kismet, Hashcat, John, Hydra, Nmap e Wireshark.
- Catalogo esteso verificato: tcpdump, Pixiewps e Bettercap aprono solo l'help; MDK4, Wifiphisher e WiFiPumpkin3 non sono avviabili dal pannello. Pyrit non è nell'allowlist.
- Hydra e Nmap vengono aperti senza target preimpostato; nessun test ha effettuato scansioni o tentativi di autenticazione.

Verificato il 7 novembre 2026 in ambiente Linux senza apparati radio.

| Requisito | Esito | Evidenza |
|---|---|---|
| R1: target singolo e anteprima | Verificato con simulazione | Test su filtro BSSID, flag di osservazione, mancata conferma e help incompatibile |
| R2: verifica locale file | Verificato su fixture | Header PCAP/PCAPNG, troncamento, righe 22000 conformi/non conformi; nessuna dichiarazione di handshake valido |
| R3: checkpoint e ripresa | Verificato con simulazione | Copia potfile, skip di fasi completate, rifiuto input/wordlist modificati |
| R4: backup | Verificato | File 600, manifest SHA-256 dei byte archiviati, niente symlink/sovrascrittura o destinazioni dentro la sessione |
| R5: importazione | Verificato con fixture | Risultati di BSSID diversi non importati; filtro hash per un solo AP |
| R6: tool esterni | Parziale | Avvio implementato, applicazioni grafiche non installate/collaudate qui |
| R7: conservazione funzioni precedenti | Parziale | Sintassi, menu, escaping, self-test e percorso offline controllati; moduli radio legacy non eseguiti |

25 test Python locali superati; 8 controlli interni superati; `bash -n` superato per entrambi i file Bash.

ShellCheck non disponibile nell'ambiente: non eseguito. Non sono stati collaudati conversioni reali, cracking reale, prestazioni GPU, Wifite installato su Kali, driver o ripristino hardware. La documentazione e l'help del Wifite locale devono essere confrontati in laboratorio.

La procedura guidata usa il programma Wifite esterno, mentre la ripresa offline è per fasi e non conserva l'offset esatto della ricerca. Gli esiti del programma non costituiscono una certificazione di vulnerabilità o un successo garantito.
